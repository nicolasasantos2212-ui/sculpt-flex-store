/**
 * Seeds the single product (id = 1). Safe to re-run: it never overwrites edits
 * you made in /admin. Set SEED_DEMO_ORDERS=1 (npm run db:seed:demo) to also
 * create sample orders + a few clearly-labelled demo reviews for local testing.
 * DELETE the demo data before launching (Admin -> Avaliações, or reset the DB).
 */
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const promoEndsAt = new Date(Date.now() + 3 * 24 * 3600 * 1000);

  await prisma.product.upsert({
    where: { id: 1 },
    update: {},
    create: {
      id: 1,
      title: "Macacão Fitness Sculpt & Flex - Costas Abertas & Efeito Empina Bumbum",
      subtitle: "Tecido canelado seamless, sem transparência, com modelagem que valoriza suas curvas.",
      oldPriceCents: 23990,
      priceCents: 11990,
      pixDiscountPct: 10,
      stock: 14,
      bannerText: "🔥 FLASH SALE: 50% OFF + FRETE GRÁTIS PARA TODO O BRASIL | POR TEMPO LIMITADO!",
      promoEndsAt,
      whatsapp: "5511999999999", // <- replace with your WhatsApp (country code + DDD + number)
      colors: JSON.stringify([
        { name: "Preto", hex: "#111111" },
        { name: "Cinza", hex: "#8b8d93" },
        { name: "Verde Oliva", hex: "#6b705c" },
        { name: "Rosa", hex: "#e07a8f" },
        { name: "Azul", hex: "#3b6ea8" },
      ]),
      sizes: JSON.stringify(["S", "M", "L"]),
      // Placeholders: replace with your own product photos (put files in /public/images
      // or use hosted URLs) — see README. `color` makes the gallery jump to that photo.
      images: JSON.stringify([
        { url: "/images/black.svg", alt: "Macacão fitness preto", color: "Preto" },
        { url: "/images/grey.svg", alt: "Macacão fitness cinza", color: "Cinza" },
        { url: "/images/olive.svg", alt: "Macacão fitness verde oliva", color: "Verde Oliva" },
        { url: "/images/rose.svg", alt: "Macacão fitness rosa", color: "Rosa" },
        { url: "/images/blue.svg", alt: "Macacão fitness azul", color: "Azul" },
        { url: "/images/back.svg", alt: "Detalhe das costas abertas" },
        { url: "/images/squat.svg", alt: "Teste do agachamento" },
        { url: "/images/texture.svg", alt: "Tecido canelado seamless" },
      ]),
    },
  });

  if (process.env.SEED_DEMO_ORDERS === "1") {
    const existing = await prisma.order.count();
    if (existing > 0) {
      console.log("Orders already exist, skipping demo data.");
      return;
    }

    const names = ["Ana Souza", "Beatriz Lima", "Camila Rocha", "Daniela Alves", "Eduarda Costa", "Fernanda Dias", "Gabriela Nunes", "Helena Martins", "Isabela Ramos", "Julia Barros"];
    const statuses = ["PAID", "SHIPPED", "DELIVERED", "PENDING", "PAID", "DELIVERED", "PENDING", "SHIPPED", "PAID", "CANCELED"];
    const colors = ["Preto", "Cinza", "Verde Oliva", "Rosa", "Azul"];
    const sizes = ["S", "M", "L"];

    for (let i = 0; i < names.length; i++) {
      const email = `demo${i + 1}@example.com`;
      const customer = await prisma.customer.create({
        data: { name: names[i], email, phone: `1198${String(1000000 + i * 1111).slice(0, 7)}`, cpf: "11144477735" },
      });
      const qty = (i % 3 === 0 ? 2 : 1);
      const pix = i % 2 === 0;
      const subtotal = 11990 * qty;
      const discount = pix ? Math.round(subtotal * 0.1) : 0;
      await prisma.order.create({
        data: {
          code: 1001 + i,
          customerId: customer.id,
          color: colors[i % colors.length],
          size: sizes[i % sizes.length],
          quantity: qty,
          subtotalCents: subtotal,
          discountCents: discount,
          totalCents: subtotal - discount,
          paymentMethod: pix ? "PIX" : "CARD",
          installments: pix ? 1 : 6,
          status: statuses[i],
          cep: "01310100",
          street: "Avenida Paulista",
          number: String(100 + i),
          complement: "",
          district: "Bela Vista",
          city: "São Paulo",
          state: "SP",
          createdAt: new Date(Date.now() - (i * 2 + 0.5) * 24 * 3600 * 1000),
        },
      });
    }

    // Roughly 5% of visits convert; gives the dashboard a realistic-looking funnel for testing.
    await prisma.visit.createMany({ data: Array.from({ length: 200 }, () => ({})) });

    await prisma.review.createMany({
      data: [
        { name: "Cliente Demo 1", email: "demo1@example.com", rating: 5, comment: "[DEMO] Avaliação de exemplo para testar o layout.", verified: false, approved: true },
        { name: "Cliente Demo 2", email: "demo2@example.com", rating: 4, comment: "[DEMO] Outro texto de exemplo para testar filtros.", verified: false, approved: true },
        { name: "Cliente Demo 3", email: "demo3@example.com", rating: 3, comment: "[DEMO] Avaliação neutra de exemplo.", verified: false, approved: true },
      ],
    });
    console.log("Demo orders, visits and reviews created.");
  }
}

main()
  .then(() => prisma.$disconnect())
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
