# Sculpt & Flex — Single-Product Store (Next.js + Prisma + Tailwind)

Mobile-first landing page + checkout + password-protected admin (`/admin`) for a one-product fitness jumpsuit store.

**Stack:** Next.js 14 (App Router) · React 18 · Tailwind CSS · Zustand · Prisma (SQLite locally, PostgreSQL in production) · lucide-react · qrcode.react

---

## 1. Run locally (5 minutes)

Requires Node.js 18.18+ (20 recommended).

```bash
npm install
cp .env.example .env        # then edit ADMIN_PASSWORD, ADMIN_SESSION_SECRET, PIX_KEY...
npm run setup               # generates Prisma client, creates the SQLite DB, seeds the product
npm run dev                 # http://localhost:3000   (admin: http://localhost:3000/admin)
```

Want sample orders/reviews to see the dashboard filled? `npm run db:seed:demo`
(**delete this demo data before launching**: Admin → Avaliações, and reset orders by deleting `prisma/dev.db` and re-running `npm run setup`).

## 2. Before you launch — checklist

| # | What | Where |
|---|------|-------|
| 1 | Replace the placeholder photos with real product photos (put files in `public/images/` or use hosted URLs). Only use images you have the right to use — supplier/AliExpress photos are often copyrighted. | `images` in `prisma/seed.ts` (before first seed) or edit the row in the DB |
| 2 | Confirm colors/sizes/features against the real product. The AliExpress page couldn't be read automatically, so colors (Preto, Cinza, Verde Oliva, Rosa, Azul), sizes (S/M/L), the size chart and benefit claims come from your brief. | `prisma/seed.ts`, `src/content/copy.ts` |
| 3 | Set your WhatsApp number | Admin → Produto & Estoque |
| 4 | Set `PIX_KEY`, `PIX_MERCHANT_NAME`, `PIX_MERCHANT_CITY` | `.env` |
| 5 | Set a strong `ADMIN_PASSWORD` and random `ADMIN_SESSION_SECRET` (`openssl rand -hex 32`) | `.env` |
| 6 | Fill in seller identification (razão social, CNPJ, address, e-mail) | `src/components/Footer.tsx` |
| 7 | Set a **realistic** delivery estimate | `DELIVERY_ESTIMATE` in `src/content/copy.ts` |
| 8 | Set a **real** promo deadline | Admin → Produto & Estoque |
| 9 | Remove demo data (if you used `db:seed:demo`) | see above |

## 3. How payments work (important)

- **PIX:** works without a gateway. The checkout generates a standard PIX *Copia e Cola* + QR Code that pays **directly into your PIX key** with the exact order amount. It's a *static* code, so there is **no automatic confirmation**: check your bank, then set the order to **Pago** in `/admin`. For automatic confirmation, integrate a gateway with webhooks (Mercado Pago, Pagar.me, Asaas, etc.).
- **Credit card:** not charged by this project. While `NEXT_PUBLIC_CARD_GATEWAY` is empty, the checkout does **not** collect card numbers; it records the order and the customer picks installments, and you send a secure payment link via WhatsApp. To charge cards in-site, integrate a gateway's hosted fields/tokenization (card data must never touch your server): set `NEXT_PUBLIC_CARD_GATEWAY` to any value to show the card form, replace `CardFields` in `src/components/Checkout.tsx` with the gateway SDK, and call the gateway from `src/app/api/orders/route.ts`.
- Prices, discounts and stock are always computed **on the server**; the browser can't tamper with them.

## 4. Deploy

### Option A — Vercel + Neon/Supabase Postgres (easiest)
1. In `prisma/schema.prisma` change `provider = "sqlite"` to `provider = "postgresql"`.
2. Create a free Postgres database (Neon, Supabase, Railway) and copy its connection string.
3. Push the project to GitHub and import it in Vercel.
4. In Vercel → Settings → Environment Variables add everything from `.env.example` (`DATABASE_URL` = your Postgres URL).
5. From your machine, once: `DATABASE_URL="<postgres url>" npx prisma db push && DATABASE_URL="<postgres url>" npm run db:seed`
6. Deploy. (`npm run build` already runs `prisma generate`.) Add your domain in Vercel.

> SQLite files do **not** persist on Vercel/serverless — use Postgres there.

### Option B — VPS (Ubuntu) with SQLite or Postgres
```bash
git clone <your repo> && cd sculpt-flex-store
npm ci && cp .env.example .env && nano .env
npm run setup && npm run build
npm i -g pm2 && pm2 start "npm start" --name store && pm2 save
```
Put Nginx/Caddy in front for HTTPS (required — the admin cookie is `secure` in production).

## 5. Admin panel (`/admin`)

- **Visão geral:** revenue, orders, conversion rate (orders ÷ visits, one visit = one browser session), today vs month, 14-day chart.
- **Pedidos:** WhatsApp link per customer, status dropdown + one-click "advance" button (Pendente → Pago → Em trânsito → Entregue). Canceling returns stock automatically.
- **Clientes:** order history and total spent.
- **Produto & Estoque:** price, old price, PIX discount, stock, banner text, promo deadline, WhatsApp, title.
- **Avaliações:** new reviews are hidden until you approve them. "Compra verificada" is set by the server only if the reviewer's e-mail matches a paid order.

## 6. Honest-marketing notes (Brazilian consumer law / CONAR)

- The rating badge, review count, and "verified" labels are computed from **real, approved reviews** — nothing is hard-coded. Don't seed fake reviews.
- The countdown follows a real deadline you set and disappears when it ends. The "restam X unidades" message shows your real stock.
- Claims like "zero transparência" must be true for the product you ship — test it.
- The old price (R$ 239,90) should be a price you really charged/advertised; otherwise the "50% OFF" claim can be considered misleading.
- Online sales have a 7-day right of withdrawal (CDC art. 49); the FAQ mentions it.

## 7. Project structure

```
prisma/            schema.prisma + seed.ts
public/images/     placeholder product images (replace!)
src/app/           page.tsx (store) · admin/ · api/ (orders, reviews, visit, admin/*)
src/components/    Header, Gallery, BuyBox, Features, Reviews, Urgency, Faq, Checkout, SizeGuide, ...
src/content/copy.ts   FAQ, benefits, size chart, brand name
src/lib/           auth, db, pix (BR Code), format/validation, zustand store
```

## 8. Known limits

- Rate limiting is in-memory (per server instance); use Redis/Upstash if you scale to several instances.
- Admin is a single shared password (HMAC-signed cookie, 12 h). Use Auth.js if you need multiple staff accounts.
- Review photos are stored in the DB as small compressed images; for lots of traffic move them to S3/Cloudinary.
