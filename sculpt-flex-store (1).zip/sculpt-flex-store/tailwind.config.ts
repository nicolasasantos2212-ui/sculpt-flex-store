import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#111111",
        lime: "#E2F163",
        rose: "#FF5A79",
      },
      fontFamily: {
        // System stack = zero font download, fastest possible first paint.
        // Want Inter/Poppins? Add next/font in layout.tsx and put it first here.
        sans: ["Inter", "ui-sans-serif", "system-ui", "-apple-system", "Segoe UI", "Roboto", "Helvetica Neue", "Arial", "sans-serif"],
      },
      keyframes: {
        pulseCta: {
          "0%, 100%": { transform: "scale(1)", boxShadow: "0 0 0 0 rgba(226,241,99,.55)" },
          "50%": { transform: "scale(1.02)", boxShadow: "0 0 0 12px rgba(226,241,99,0)" },
        },
      },
      animation: { pulseCta: "pulseCta 2s ease-in-out infinite" },
    },
  },
  plugins: [],
};

export default config;
