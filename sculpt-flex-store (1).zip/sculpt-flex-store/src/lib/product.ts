import { prisma } from "./db";

export type ColorOpt = { name: string; hex: string };
export type ImageOpt = { url: string; alt: string; color?: string };

/** Loads the single product and parses its JSON columns. Returns null if the DB isn't seeded. */
export async function getProduct() {
  const p = await prisma.product.findUnique({ where: { id: 1 } });
  if (!p) return null;
  return {
    id: p.id,
    title: p.title,
    subtitle: p.subtitle,
    oldPriceCents: p.oldPriceCents,
    priceCents: p.priceCents,
    pixDiscountPct: p.pixDiscountPct,
    stock: p.stock,
    bannerText: p.bannerText,
    whatsapp: p.whatsapp,
    colors: JSON.parse(p.colors) as ColorOpt[],
    sizes: JSON.parse(p.sizes) as string[],
    images: JSON.parse(p.images) as ImageOpt[],
    promoEndsAt: p.promoEndsAt.toISOString(),
  };
}

export type PublicProduct = NonNullable<Awaited<ReturnType<typeof getProduct>>>;

export type PublicReview = {
  id: string;
  name: string;
  rating: number;
  comment: string;
  photo: string | null;
  verified: boolean;
  createdAt: string;
};

/** Approved reviews only. The e-mail column is never selected. */
export async function getReviews(): Promise<{ reviews: PublicReview[]; average: number; count: number }> {
  const rows = await prisma.review.findMany({
    where: { approved: true },
    orderBy: { createdAt: "desc" },
    select: { id: true, name: true, rating: true, comment: true, photo: true, verified: true, createdAt: true },
  });
  const count = rows.length;
  const average = count ? rows.reduce((s, r) => s + r.rating, 0) / count : 0;
  return {
    reviews: rows.slice(0, 60).map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })),
    average,
    count,
  };
}
