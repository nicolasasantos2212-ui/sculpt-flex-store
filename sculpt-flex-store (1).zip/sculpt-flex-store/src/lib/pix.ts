/**
 * Static PIX "Copia e Cola" (BR Code / EMV-MPM) generator.
 *
 * No payment gateway needed: the QR code pays straight into YOUR PIX key.
 * Because it is a static code there is no automatic payment notification, so
 * you confirm payments manually in /admin (Status -> Pago), or replace this
 * module with a gateway that issues dynamic charges + webhooks.
 */

const field = (id: string, value: string) => id + String(value.length).padStart(2, "0") + value;

/** Removes accents, keeps only characters allowed in PIX text fields, uppercases and truncates. */
const clean = (s: string, max: number) =>
  s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^A-Za-z0-9 ]/g, "")
    .toUpperCase()
    .trim()
    .slice(0, max);

/** CRC16-CCITT (poly 0x1021, init 0xFFFF) as required by the BR Code spec. */
function crc16(payload: string): string {
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

export function buildPixPayload(opts: {
  key: string;
  name: string;
  city: string;
  amountCents: number;
  txid: string;
}): string {
  const account = field("00", "br.gov.bcb.pix") + field("01", opts.key.trim());
  const txid = opts.txid.replace(/[^A-Za-z0-9]/g, "").slice(0, 25) || "***";
  const body =
    field("00", "01") +
    field("26", account) +
    field("52", "0000") +
    field("53", "986") +
    field("54", (opts.amountCents / 100).toFixed(2)) +
    field("58", "BR") +
    field("59", clean(opts.name, 25) || "LOJA") +
    field("60", clean(opts.city, 15) || "SAO PAULO") +
    field("62", field("05", txid)) +
    "6304";
  return body + crc16(body);
}

/** Returns the payload for an order, or null when PIX_KEY isn't configured. */
export function pixForOrder(code: number, amountCents: number): string | null {
  const key = process.env.PIX_KEY;
  if (!key) return null;
  return buildPixPayload({
    key,
    name: process.env.PIX_MERCHANT_NAME || "LOJA",
    city: process.env.PIX_MERCHANT_CITY || "SAO PAULO",
    amountCents,
    txid: `PED${code}`,
  });
}
