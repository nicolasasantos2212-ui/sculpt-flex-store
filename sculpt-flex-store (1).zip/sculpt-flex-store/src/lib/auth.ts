import crypto from "crypto";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";

/**
 * Minimal admin auth: one password (env) -> HMAC-signed, expiring, httpOnly cookie.
 * Good enough for a single-owner store. For multiple staff users, swap for
 * NextAuth/Auth.js or your IdP.
 */

export const COOKIE_NAME = "sf_admin";
const TTL_SECONDS = 60 * 60 * 12; // 12 hours

function secret(): string | null {
  const s = process.env.ADMIN_SESSION_SECRET;
  if (s) return s;
  // Never fall back to a known secret in production.
  return process.env.NODE_ENV === "production" ? null : "dev-only-secret";
}

const sign = (value: string, key: string) =>
  crypto.createHmac("sha256", key).update(value).digest("hex");

export function checkPassword(input: string): boolean {
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected || !secret()) return false;
  const a = crypto.createHash("sha256").update(input).digest();
  const b = crypto.createHash("sha256").update(expected).digest();
  return crypto.timingSafeEqual(a, b);
}

export function createSessionToken(): string {
  const key = secret();
  if (!key) throw new Error("ADMIN_SESSION_SECRET is not set");
  const exp = Math.floor(Date.now() / 1000) + TTL_SECONDS;
  return `${exp}.${sign(String(exp), key)}`;
}

export const sessionCookieOptions = {
  httpOnly: true,
  sameSite: "strict" as const,
  secure: process.env.NODE_ENV === "production",
  path: "/",
  maxAge: TTL_SECONDS,
};

export function isAdmin(): boolean {
  const key = secret();
  if (!key) return false;
  const token = cookies().get(COOKIE_NAME)?.value;
  if (!token) return false;
  const [exp, sig] = token.split(".");
  if (!exp || !sig) return false;
  const expected = sign(exp, key);
  if (sig.length !== expected.length) return false;
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;
  return Number(exp) > Math.floor(Date.now() / 1000);
}

/** Use at the top of every admin API route: `const denied = guard(); if (denied) return denied;` */
export function guard(): NextResponse | null {
  return isAdmin() ? null : NextResponse.json({ error: "Não autorizado" }, { status: 401 });
}

/** Tiny in-memory rate limiter (per server instance). Use Redis/Upstash for multi-instance deployments. */
const hits = new Map<string, { count: number; reset: number }>();
export function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const h = hits.get(key);
  if (!h || h.reset < now) {
    hits.set(key, { count: 1, reset: now + windowMs });
    return true;
  }
  h.count += 1;
  return h.count <= max;
}

export function clientIp(req: Request): string {
  return req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "local";
}
