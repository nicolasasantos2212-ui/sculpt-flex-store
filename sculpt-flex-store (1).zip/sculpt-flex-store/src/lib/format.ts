/** Shared formatting + validation helpers (safe for client and server). */

export const brl = (cents: number) =>
  (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export const digits = (s: string) => s.replace(/\D/g, "");

/** Installment value rounded UP so the sum never falls short of the total. */
export const installment = (totalCents: number, n: number) => Math.ceil(totalCents / n);

export function validCPF(raw: string): boolean {
  const c = digits(raw);
  if (c.length !== 11 || /^(\d)\1+$/.test(c)) return false;
  for (let t = 9; t < 11; t++) {
    let sum = 0;
    for (let i = 0; i < t; i++) sum += parseInt(c[i], 10) * (t + 1 - i);
    const d = ((sum * 10) % 11) % 10;
    if (d !== parseInt(c[t], 10)) return false;
  }
  return true;
}

export const validEmail = (s: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s.trim());

export const maskCPF = (v: string) =>
  digits(v)
    .slice(0, 11)
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");

export const maskPhone = (v: string) => {
  const d = digits(v).slice(0, 11);
  if (d.length <= 10) return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{4})(\d)/, "$1-$2");
  return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{5})(\d)/, "$1-$2");
};

export const maskCEP = (v: string) => digits(v).slice(0, 8).replace(/(\d{5})(\d)/, "$1-$2");

export const maskCard = (v: string) =>
  digits(v)
    .slice(0, 16)
    .replace(/(\d{4})(?=\d)/g, "$1 ");

export const maskExpiry = (v: string) => digits(v).slice(0, 4).replace(/(\d{2})(\d)/, "$1/$2");

export const dateBR = (d: string | Date) =>
  new Date(d).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", timeZone: "America/Sao_Paulo" });

export const dateTimeBR = (d: string | Date) =>
  new Date(d).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short", timeZone: "America/Sao_Paulo" });
