"use client";

import { create } from "zustand";

/**
 * Cart + UI state. Single-product store, so the "cart" is one line:
 * the selected variant (color/size) and quantity.
 */
type State = {
  color: string;
  size: string;
  qty: number;
  inCart: boolean;
  checkoutOpen: boolean;
  sizeGuideOpen: boolean;
  init: (color: string) => void;
  setColor: (c: string) => void;
  setSize: (s: string) => void;
  setQty: (n: number) => void;
  buyNow: () => void;
  openCheckout: () => void;
  closeCheckout: () => void;
  clearCart: () => void;
  setSizeGuide: (open: boolean) => void;
};

export const useStore = create<State>((set) => ({
  color: "",
  size: "",
  qty: 1,
  inCart: false,
  checkoutOpen: false,
  sizeGuideOpen: false,
  init: (color) => set((s) => (s.color ? s : { color })),
  setColor: (color) => set({ color }),
  setSize: (size) => set({ size }),
  setQty: (qty) => set({ qty: Math.min(5, Math.max(1, qty)) }),
  buyNow: () => set({ inCart: true, checkoutOpen: true }),
  openCheckout: () => set({ checkoutOpen: true }),
  closeCheckout: () => set({ checkoutOpen: false }),
  clearCart: () => set({ inCart: false, qty: 1 }),
  setSizeGuide: (sizeGuideOpen) => set({ sizeGuideOpen }),
}));

/** Scrolls to the purchase box (used by header cart icon and sticky mobile button). */
export const scrollToBuy = () => document.getElementById("comprar")?.scrollIntoView({ behavior: "smooth", block: "start" });
