"use client";

import { useCallback, useEffect, useState } from "react";
import { BarChart3, LogOut, MessageCircle, Package, ShoppingCart, Star, Users } from "lucide-react";
import { brl, dateTimeBR, digits } from "@/lib/format";

/* ------------------------------------------------------------------ types -- */
type Tab = "overview" | "orders" | "customers" | "product" | "reviews";
type Stats = {
  totalRevenueCents: number; totalOrders: number; pendingOrders: number; visits: number; conversionRate: number;
  todayRevenueCents: number; todayOrders: number; monthRevenueCents: number; monthOrders: number; stock: number;
  series: { date: string; revenueCents: number; orders: number }[];
};
type Order = {
  id: string; code: number; color: string; size: string; quantity: number; totalCents: number; paymentMethod: string;
  installments: number; status: string; createdAt: string; city: string; state: string;
  customer: { name: string; email: string; phone: string };
};
type CustomerRow = {
  id: string; name: string; email: string; phone: string; ordersCount: number; totalSpentCents: number; lastOrderAt: string | null;
  history: { code: number; status: string; totalCents: number; createdAt: string }[];
};
type ProductData = {
  title: string; subtitle: string; priceCents: number; oldPriceCents: number; pixDiscountPct: number; stock: number;
  bannerText: string; promoEndsAt: string; whatsapp: string;
};
type ReviewRow = { id: string; name: string; email: string; rating: number; comment: string; photo: string | null; verified: boolean; approved: boolean; createdAt: string };

const STATUS: Record<string, { label: string; cls: string }> = {
  PENDING: { label: "Pendente", cls: "bg-amber-100 text-amber-800" },
  PAID: { label: "Pago", cls: "bg-green-100 text-green-800" },
  SHIPPED: { label: "Em trânsito", cls: "bg-blue-100 text-blue-800" },
  DELIVERED: { label: "Entregue", cls: "bg-neutral-200 text-neutral-800" },
  CANCELED: { label: "Cancelado", cls: "bg-red-100 text-red-800" },
};
const NEXT: Record<string, string> = { PENDING: "PAID", PAID: "SHIPPED", SHIPPED: "DELIVERED" };
const NEXT_LABEL: Record<string, string> = { PENDING: "Marcar como pago", PAID: "Marcar em trânsito", SHIPPED: "Marcar entregue" };

/* ---------------------------------------------------------------- helpers -- */
class Unauthorized extends Error {}

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, { ...init, headers: { "Content-Type": "application/json", ...(init?.headers || {}) } });
  if (res.status === 401) throw new Unauthorized();
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as any).error || "Erro inesperado");
  return data as T;
}

const waLink = (phone: string, text = "") => `https://wa.me/55${digits(phone)}${text ? `?text=${encodeURIComponent(text)}` : ""}`;

function Badge({ status }: { status: string }) {
  const s = STATUS[status] ?? { label: status, cls: "bg-neutral-100" };
  return <span className={`inline-block rounded-full px-2.5 py-1 text-xs font-bold ${s.cls}`}>{s.label}</span>;
}

/* ------------------------------------------------------------------- page -- */
export default function AdminPage() {
  const [auth, setAuth] = useState<"loading" | "in" | "out">("loading");

  useEffect(() => {
    fetch("/api/admin/stats").then((r) => setAuth(r.ok ? "in" : "out")).catch(() => setAuth("out"));
  }, []);

  if (auth === "loading") return <p className="p-8 text-center text-neutral-500">Carregando…</p>;
  if (auth === "out") return <Login onDone={() => setAuth("in")} />;
  return <Dashboard onLogout={() => setAuth("out")} />;
}

function Login({ onDone }: { onDone: () => void }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      await api("/api/admin/login", { method: "POST", body: JSON.stringify({ password }) });
      onDone();
    } catch (err: any) {
      setError(err instanceof Unauthorized ? "Senha incorreta" : err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center p-4">
      <form onSubmit={submit} className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-lg">
        <h1 className="text-2xl font-black">Painel Admin</h1>
        <p className="mt-1 text-sm text-neutral-500">Sculpt &amp; Flex</p>
        <input type="password" autoFocus autoComplete="current-password" className="input mt-5" placeholder="Senha" value={password} onChange={(e) => setPassword(e.target.value)} />
        {error && <p className="mt-2 text-sm font-semibold text-red-600">{error}</p>}
        <button disabled={loading || !password} className="mt-4 h-12 w-full rounded-xl bg-ink font-bold text-white disabled:opacity-50">
          {loading ? "Entrando…" : "Entrar"}
        </button>
      </form>
    </main>
  );
}

function Dashboard({ onLogout }: { onLogout: () => void }) {
  const [tab, setTab] = useState<Tab>("overview");

  const logout = async () => {
    await fetch("/api/admin/login", { method: "DELETE" });
    onLogout();
  };

  const tabs: { id: Tab; label: string; Icon: typeof Package }[] = [
    { id: "overview", label: "Visão geral", Icon: BarChart3 },
    { id: "orders", label: "Pedidos", Icon: ShoppingCart },
    { id: "customers", label: "Clientes", Icon: Users },
    { id: "product", label: "Produto & Estoque", Icon: Package },
    { id: "reviews", label: "Avaliações", Icon: Star },
  ];

  return (
    <div className="mx-auto max-w-6xl p-4">
      <header className="flex items-center justify-between py-3">
        <h1 className="text-xl font-black">Sculpt &amp; Flex · Admin</h1>
        <div className="flex items-center gap-2">
          <a href="/" target="_blank" className="text-sm font-semibold underline">Ver loja</a>
          <button onClick={logout} className="flex h-10 items-center gap-1.5 rounded-xl bg-white px-3 text-sm font-semibold shadow-sm">
            <LogOut className="h-4 w-4" /> Sair
          </button>
        </div>
      </header>

      <nav className="no-scrollbar mb-4 flex gap-2 overflow-x-auto" aria-label="Seções">
        {tabs.map(({ id, label, Icon }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            aria-current={tab === id}
            className={`flex h-11 shrink-0 items-center gap-2 rounded-xl px-4 text-sm font-bold ${tab === id ? "bg-ink text-white" : "bg-white"}`}
          >
            <Icon className="h-4 w-4" /> {label}
          </button>
        ))}
      </nav>

      {tab === "overview" && <Overview onLogout={onLogout} />}
      {tab === "orders" && <Orders onLogout={onLogout} />}
      {tab === "customers" && <Customers onLogout={onLogout} />}
      {tab === "product" && <ProductSettings onLogout={onLogout} />}
      {tab === "reviews" && <Reviews onLogout={onLogout} />}
    </div>
  );
}

/** Loads data and bounces to the login screen when the session expires. */
function useLoad<T>(url: string, onLogout: () => void) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState("");
  const load = useCallback(async () => {
    try {
      setData(await api<T>(url));
      setError("");
    } catch (e: any) {
      if (e instanceof Unauthorized) onLogout();
      else setError(e.message);
    }
  }, [url, onLogout]);
  useEffect(() => {
    load();
  }, [load]);
  return { data, error, reload: load, setData };
}

const Card = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => (
  <div className={`rounded-2xl bg-white p-4 shadow-sm ${className}`}>{children}</div>
);

/* --------------------------------------------------------------- overview -- */
function Overview({ onLogout }: { onLogout: () => void }) {
  const { data: s, error } = useLoad<Stats>("/api/admin/stats", onLogout);
  if (error) return <p className="text-red-600">{error}</p>;
  if (!s) return <p className="text-neutral-500">Carregando…</p>;

  const kpis = [
    { label: "Receita total", value: brl(s.totalRevenueCents), sub: "pedidos pagos, enviados e entregues" },
    { label: "Pedidos", value: String(s.totalOrders), sub: `${s.pendingOrders} pendente(s)` },
    { label: "Conversão", value: `${s.conversionRate.toFixed(1)}%`, sub: `${s.visits} visitas (sessões)` },
    { label: "Estoque", value: String(s.stock), sub: "unidades disponíveis" },
  ];
  const max = Math.max(1, ...s.series.map((d) => d.revenueCents));

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {kpis.map((k) => (
          <Card key={k.label}>
            <p className="text-xs font-semibold uppercase tracking-wide text-neutral-500">{k.label}</p>
            <p className="mt-1 text-2xl font-black">{k.value}</p>
            <p className="text-xs text-neutral-500">{k.sub}</p>
          </Card>
        ))}
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <Card>
          <p className="text-xs font-semibold uppercase text-neutral-500">Vendas de hoje</p>
          <p className="text-2xl font-black">{brl(s.todayRevenueCents)}</p>
          <p className="text-xs text-neutral-500">{s.todayOrders} pedido(s)</p>
        </Card>
        <Card>
          <p className="text-xs font-semibold uppercase text-neutral-500">Vendas do mês</p>
          <p className="text-2xl font-black">{brl(s.monthRevenueCents)}</p>
          <p className="text-xs text-neutral-500">{s.monthOrders} pedido(s)</p>
        </Card>
      </div>

      <Card>
        <p className="font-bold">Receita dos últimos 14 dias</p>
        <div className="mt-4 flex h-44 items-end gap-1.5" role="img" aria-label="Gráfico de barras da receita diária dos últimos 14 dias">
          {s.series.map((d) => (
            <div key={d.date} className="flex h-full flex-1 flex-col justify-end" title={`${d.date.split("-").reverse().join("/")}: ${brl(d.revenueCents)} (${d.orders} pedido(s))`}>
              <div className="w-full rounded-t bg-ink" style={{ height: `${Math.max(d.revenueCents ? 4 : 1, (d.revenueCents / max) * 100)}%`, opacity: d.revenueCents ? 1 : 0.15 }} />
            </div>
          ))}
        </div>
        <div className="mt-1 flex gap-1.5 text-[10px] text-neutral-500">
          {s.series.map((d, i) => (
            <span key={d.date} className="flex-1 text-center">{i % 2 === 0 ? d.date.slice(8) : ""}</span>
          ))}
        </div>
        <p className="mt-2 text-xs text-neutral-500">Dia do mês no eixo X · passe o mouse / toque numa barra para ver o valor.</p>
      </Card>
    </div>
  );
}

/* ----------------------------------------------------------------- orders -- */
function Orders({ onLogout }: { onLogout: () => void }) {
  const [filter, setFilter] = useState("ALL");
  const { data: orders, error, reload } = useLoad<Order[]>(`/api/admin/orders?status=${filter}`, onLogout);
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState("");

  const setStatus = async (id: string, status: string) => {
    setBusy(id);
    setMsg("");
    try {
      await api(`/api/admin/orders/${id}`, { method: "PATCH", body: JSON.stringify({ status }) });
      await reload();
    } catch (e: any) {
      if (e instanceof Unauthorized) onLogout();
      else setMsg(e.message);
    } finally {
      setBusy(null);
    }
  };

  return (
    <Card>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-lg font-black">Pedidos</h2>
        <select className="input !w-auto !py-2" value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="Filtrar por status">
          <option value="ALL">Todos</option>
          {Object.entries(STATUS).map(([k, v]) => (
            <option key={k} value={k}>{v.label}</option>
          ))}
        </select>
      </div>
      {(error || msg) && <p className="mb-2 text-sm font-semibold text-red-600">{error || msg}</p>}
      {!orders ? (
        <p className="text-neutral-500">Carregando…</p>
      ) : orders.length === 0 ? (
        <p className="text-neutral-500">Nenhum pedido ainda.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[860px] text-left text-sm">
            <thead className="border-b text-xs uppercase text-neutral-500">
              <tr>
                <th className="py-2">Pedido</th><th>Cliente</th><th>WhatsApp</th><th>Item</th><th>Total</th><th>Pagamento</th><th>Status</th><th>Ação</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id} className="border-b border-neutral-100 align-top">
                  <td className="py-3"><b>#{o.code}</b><div className="text-xs text-neutral-500">{dateTimeBR(o.createdAt)}</div></td>
                  <td>{o.customer.name}<div className="text-xs text-neutral-500">{o.city}/{o.state}</div></td>
                  <td>
                    <a href={waLink(o.customer.phone, `Olá ${o.customer.name.split(" ")[0]}! Sobre seu pedido #${o.code}:`)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 font-semibold text-green-700 underline">
                      <MessageCircle className="h-4 w-4" /> {o.customer.phone}
                    </a>
                  </td>
                  <td>{o.quantity}× {o.color} / {o.size}</td>
                  <td className="font-bold">{brl(o.totalCents)}</td>
                  <td>{o.paymentMethod === "PIX" ? "PIX" : `Cartão ${o.installments}x`}</td>
                  <td>
                    <select
                      value={o.status}
                      disabled={busy === o.id}
                      onChange={(e) => setStatus(o.id, e.target.value)}
                      className="rounded-lg border border-neutral-300 px-2 py-1.5 text-xs font-bold"
                      aria-label={`Status do pedido ${o.code}`}
                    >
                      {Object.entries(STATUS).map(([k, v]) => (<option key={k} value={k}>{v.label}</option>))}
                    </select>
                    <div className="mt-1"><Badge status={o.status} /></div>
                  </td>
                  <td>
                    {NEXT[o.status] && (
                      <button disabled={busy === o.id} onClick={() => setStatus(o.id, NEXT[o.status])} className="rounded-lg bg-ink px-3 py-2 text-xs font-bold text-white disabled:opacity-50">
                        {NEXT_LABEL[o.status]}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}

/* -------------------------------------------------------------- customers -- */
function Customers({ onLogout }: { onLogout: () => void }) {
  const { data, error } = useLoad<CustomerRow[]>("/api/admin/customers", onLogout);
  const [open, setOpen] = useState<string | null>(null);

  return (
    <Card>
      <h2 className="mb-3 text-lg font-black">Clientes</h2>
      {error && <p className="text-red-600">{error}</p>}
      {!data ? <p className="text-neutral-500">Carregando…</p> : data.length === 0 ? <p className="text-neutral-500">Nenhum cliente ainda.</p> : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead className="border-b text-xs uppercase text-neutral-500">
              <tr><th className="py-2">Cliente</th><th>Contato</th><th>Pedidos</th><th>Total gasto</th><th>Último pedido</th></tr>
            </thead>
            <tbody>
              {data.map((c) => (
                <FragmentRow key={c.id} c={c} open={open === c.id} toggle={() => setOpen(open === c.id ? null : c.id)} />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}

function FragmentRow({ c, open, toggle }: { c: CustomerRow; open: boolean; toggle: () => void }) {
  return (
    <>
      <tr className="cursor-pointer border-b border-neutral-100 hover:bg-neutral-50" onClick={toggle}>
        <td className="py-3 font-semibold">{c.name}<div className="text-xs font-normal text-neutral-500">{c.email}</div></td>
        <td>
          <a href={waLink(c.phone)} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} className="inline-flex items-center gap-1 font-semibold text-green-700 underline">
            <MessageCircle className="h-4 w-4" /> {c.phone}
          </a>
        </td>
        <td>{c.ordersCount}</td>
        <td className="font-bold">{brl(c.totalSpentCents)}</td>
        <td>{c.lastOrderAt ? dateTimeBR(c.lastOrderAt) : "—"}</td>
      </tr>
      {open && (
        <tr className="bg-neutral-50">
          <td colSpan={5} className="px-3 py-3">
            <p className="mb-1 text-xs font-bold uppercase text-neutral-500">Histórico</p>
            <ul className="space-y-1">
              {c.history.map((h) => (
                <li key={h.code} className="flex flex-wrap items-center gap-3 text-sm">
                  <b>#{h.code}</b> <span>{dateTimeBR(h.createdAt)}</span> <span>{brl(h.totalCents)}</span> <Badge status={h.status} />
                </li>
              ))}
            </ul>
          </td>
        </tr>
      )}
    </>
  );
}

/* ---------------------------------------------------------------- product -- */
const toCents = (v: string) => Math.round(parseFloat(v.replace(/\./g, "").replace(",", ".")) * 100);
const fromCents = (c: number) => (c / 100).toFixed(2).replace(".", ",");
const toLocalInput = (iso: string) => {
  const d = new Date(iso);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};

function ProductSettings({ onLogout }: { onLogout: () => void }) {
  const { data: p, error } = useLoad<ProductData>("/api/admin/product", onLogout);
  const [form, setForm] = useState<Record<string, string> | null>(null);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    if (!p) return;
    setForm({
      title: p.title, subtitle: p.subtitle, price: fromCents(p.priceCents), oldPrice: fromCents(p.oldPriceCents),
      pixDiscountPct: String(p.pixDiscountPct), stock: String(p.stock), bannerText: p.bannerText,
      promoEndsAt: toLocalInput(p.promoEndsAt), whatsapp: p.whatsapp,
    });
  }, [p]);

  if (error) return <p className="text-red-600">{error}</p>;
  if (!form) return <p className="text-neutral-500">Carregando…</p>;

  const upd = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setForm({ ...form, [k]: e.target.value });

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMsg(null);
    try {
      await api("/api/admin/product", {
        method: "PUT",
        body: JSON.stringify({
          title: form.title, subtitle: form.subtitle, priceCents: toCents(form.price), oldPriceCents: toCents(form.oldPrice),
          pixDiscountPct: parseInt(form.pixDiscountPct, 10), stock: parseInt(form.stock, 10), bannerText: form.bannerText,
          promoEndsAt: new Date(form.promoEndsAt).toISOString(), whatsapp: form.whatsapp,
        }),
      });
      setMsg({ ok: true, text: "Salvo! A loja já está atualizada." });
    } catch (err: any) {
      if (err instanceof Unauthorized) return onLogout();
      setMsg({ ok: false, text: err.message });
    } finally {
      setSaving(false);
    }
  };

  const L = ({ t, children }: { t: string; children: React.ReactNode }) => (
    <label className="block text-sm font-semibold">{t}<div className="mt-1 font-normal">{children}</div></label>
  );

  return (
    <Card>
      <h2 className="mb-3 text-lg font-black">Produto &amp; Estoque</h2>
      <form onSubmit={save} className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2"><L t="Título"><input className="input" value={form.title} onChange={upd("title")} /></L></div>
        <div className="sm:col-span-2"><L t="Subtítulo"><input className="input" value={form.subtitle} onChange={upd("subtitle")} /></L></div>
        <L t="Preço promocional (R$)"><input className="input" inputMode="decimal" value={form.price} onChange={upd("price")} /></L>
        <L t="Preço antigo (R$)"><input className="input" inputMode="decimal" value={form.oldPrice} onChange={upd("oldPrice")} /></L>
        <L t="Desconto no PIX (%)"><input className="input" inputMode="numeric" value={form.pixDiscountPct} onChange={upd("pixDiscountPct")} /></L>
        <L t="Estoque (unidades)"><input className="input" inputMode="numeric" value={form.stock} onChange={upd("stock")} /></L>
        <div className="sm:col-span-2"><L t="Texto da barra de anúncio"><textarea className="input" rows={2} value={form.bannerText} onChange={upd("bannerText")} /></L></div>
        <L t="Fim da promoção (contador regressivo)"><input type="datetime-local" className="input" value={form.promoEndsAt} onChange={upd("promoEndsAt")} /></L>
        <L t="WhatsApp (55 + DDD + número)"><input className="input" inputMode="numeric" value={form.whatsapp} onChange={upd("whatsapp")} /></L>
        <div className="sm:col-span-2">
          {msg && <p className={`mb-2 text-sm font-semibold ${msg.ok ? "text-green-700" : "text-red-600"}`}>{msg.text}</p>}
          <button disabled={saving} className="h-12 rounded-xl bg-ink px-8 font-bold text-white disabled:opacity-60">{saving ? "Salvando…" : "Salvar alterações"}</button>
        </div>
      </form>
      <p className="mt-4 text-xs text-neutral-500">Use um prazo real no contador: quando ele termina, o timer some da loja. Cores, tamanhos e fotos ficam em <code>prisma/seed.ts</code> (ou direto no banco).</p>
    </Card>
  );
}

/* ---------------------------------------------------------------- reviews -- */
function Reviews({ onLogout }: { onLogout: () => void }) {
  const { data, error, reload } = useLoad<ReviewRow[]>("/api/admin/reviews", onLogout);

  const act = async (id: string, fn: () => Promise<unknown>) => {
    try {
      await fn();
      await reload();
    } catch (e) {
      if (e instanceof Unauthorized) onLogout();
    }
  };

  return (
    <Card>
      <h2 className="mb-1 text-lg font-black">Avaliações</h2>
      <p className="mb-3 text-sm text-neutral-500">Novas avaliações só aparecem na loja depois de aprovadas aqui.</p>
      {error && <p className="text-red-600">{error}</p>}
      {!data ? <p className="text-neutral-500">Carregando…</p> : data.length === 0 ? <p className="text-neutral-500">Nenhuma avaliação.</p> : (
        <ul className="space-y-3">
          {data.map((r) => (
            <li key={r.id} className="rounded-xl border border-neutral-200 p-3">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <b>{r.name}</b> <span className="text-neutral-500">{r.email}</span>
                <span className="text-amber-500">{"★".repeat(r.rating)}<span className="text-neutral-300">{"★".repeat(5 - r.rating)}</span></span>
                {r.verified && <span className="rounded-full bg-green-100 px-2 py-0.5 text-xs font-bold text-green-800">Compra verificada</span>}
                <span className={`rounded-full px-2 py-0.5 text-xs font-bold ${r.approved ? "bg-neutral-100" : "bg-amber-100 text-amber-800"}`}>{r.approved ? "Publicada" : "Aguardando"}</span>
              </div>
              <p className="mt-2 text-sm">{r.comment}</p>
              {r.photo && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={r.photo} alt="Foto enviada" className="mt-2 h-20 w-20 rounded-lg object-cover" />
              )}
              <div className="mt-3 flex gap-2">
                <button onClick={() => act(r.id, () => api(`/api/admin/reviews/${r.id}`, { method: "PATCH", body: JSON.stringify({ approved: !r.approved }) }))} className="rounded-lg bg-ink px-3 py-2 text-xs font-bold text-white">
                  {r.approved ? "Despublicar" : "Aprovar e publicar"}
                </button>
                <button
                  onClick={() => confirm("Excluir esta avaliação?") && act(r.id, () => api(`/api/admin/reviews/${r.id}`, { method: "DELETE" }))}
                  className="rounded-lg border border-red-300 px-3 py-2 text-xs font-bold text-red-700"
                >
                  Excluir
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
