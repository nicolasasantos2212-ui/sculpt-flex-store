import type { Metadata } from "next";

// Keep the admin panel out of search engines.
export const metadata: Metadata = {
  title: "Admin | Sculpt & Flex",
  robots: { index: false, follow: false },
};

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return <div className="min-h-screen bg-neutral-100">{children}</div>;
}
