import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Macacão Fitness Sculpt & Flex | Costas Abertas + Frete Grátis",
  description:
    "Macacão fitness com costas abertas, efeito empina bumbum e tecido canelado seamless sem transparência. Frete grátis para todo o Brasil e 7 dias de garantia.",
  openGraph: {
    title: "Macacão Fitness Sculpt & Flex",
    description: "Costas abertas, efeito empina bumbum e tecido sem transparência. Frete grátis para todo o Brasil.",
    type: "website",
    locale: "pt_BR",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#111111",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
