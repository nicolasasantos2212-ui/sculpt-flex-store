import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { clientIp, rateLimit } from "@/lib/auth";
import { validEmail } from "@/lib/format";

const MAX_PHOTO_CHARS = 450_000; // ~330 KB; the client compresses to far less

/**
 * Customer review submission. Reviews are NOT public until approved in /admin.
 * The "verified buyer" flag is set server-side by matching the e-mail against
 * a customer with a paid/shipped/delivered order — it can't be faked by the client.
 */
export async function POST(req: Request) {
  if (!rateLimit(`review:${clientIp(req)}`, 5, 10 * 60_000)) {
    return NextResponse.json({ error: "Muitas tentativas. Tente novamente mais tarde." }, { status: 429 });
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Requisição inválida" }, { status: 400 });
  }

  const name = String(body?.name ?? "").trim().slice(0, 60);
  const email = String(body?.email ?? "").trim().toLowerCase().slice(0, 160);
  const comment = String(body?.comment ?? "").trim().slice(0, 1000);
  const rating = Math.floor(Number(body?.rating));
  let photo: string | null = typeof body?.photo === "string" && body.photo ? body.photo : null;

  if (name.length < 2) return NextResponse.json({ error: "Informe seu nome" }, { status: 400 });
  if (!validEmail(email)) return NextResponse.json({ error: "E-mail inválido" }, { status: 400 });
  if (!(rating >= 1 && rating <= 5)) return NextResponse.json({ error: "Escolha de 1 a 5 estrelas" }, { status: 400 });
  if (comment.length < 5) return NextResponse.json({ error: "Escreva um comentário" }, { status: 400 });

  if (photo) {
    const ok = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(photo) && photo.length <= MAX_PHOTO_CHARS;
    if (!ok) return NextResponse.json({ error: "Foto inválida ou muito grande" }, { status: 400 });
  }

  const buyer = await prisma.customer.findUnique({
    where: { email },
    include: { orders: { where: { status: { in: ["PAID", "SHIPPED", "DELIVERED"] } }, select: { id: true }, take: 1 } },
  });

  await prisma.review.create({
    data: { name, email, rating, comment, photo, verified: !!buyer && buyer.orders.length > 0, approved: false },
  });

  return NextResponse.json({ ok: true, message: "Obrigado! Sua avaliação será publicada após a moderação." });
}
