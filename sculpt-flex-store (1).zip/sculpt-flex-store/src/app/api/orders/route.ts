import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { clientIp, rateLimit } from "@/lib/auth";
import { digits, validCPF, validEmail } from "@/lib/format";
import { getProduct } from "@/lib/product";
import { pixForOrder } from "@/lib/pix";

/**
 * Creates an order.
 * SECURITY: prices, discounts and stock are always computed here from the DB —
 * the client only sends *what* to buy, never *how much it costs*.
 * Card numbers are intentionally never accepted by this endpoint. To charge
 * cards, integrate a gateway's hosted fields/tokenization (see README).
 */
export async function POST(req: Request) {
  if (!rateLimit(`order:${clientIp(req)}`, 10, 60_000)) {
    return NextResponse.json({ error: "Muitas tentativas. Aguarde um minuto." }, { status: 429 });
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Requisição inválida" }, { status: 400 });
  }

  const product = await getProduct();
  if (!product) return NextResponse.json({ error: "Produto indisponível" }, { status: 503 });

  const str = (v: unknown, max = 120) => (typeof v === "string" ? v.trim().slice(0, max) : "");
  const c = body?.customer ?? {};
  const a = body?.address ?? {};

  const color = str(body?.color, 40);
  const size = str(body?.size, 10);
  const quantity = Number(body?.quantity);
  const paymentMethod = body?.paymentMethod === "CARD" ? "CARD" : body?.paymentMethod === "PIX" ? "PIX" : null;
  const installments = paymentMethod === "CARD" ? Math.min(12, Math.max(1, Math.floor(Number(body?.installments) || 1))) : 1;

  const customer = { name: str(c.name), email: str(c.email, 160).toLowerCase(), phone: digits(str(c.phone, 20)), cpf: digits(str(c.cpf, 20)) };
  const address = {
    cep: digits(str(a.cep, 12)),
    street: str(a.street),
    number: str(a.number, 20),
    complement: str(a.complement, 60),
    district: str(a.district, 80),
    city: str(a.city, 80),
    state: str(a.state, 2).toUpperCase(),
  };

  // ---- validation ----------------------------------------------------------
  const errors: string[] = [];
  if (!product.colors.some((x) => x.name === color)) errors.push("Cor inválida");
  if (!product.sizes.includes(size)) errors.push("Tamanho inválido");
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 5) errors.push("Quantidade inválida (1 a 5)");
  if (!paymentMethod) errors.push("Forma de pagamento inválida");
  if (customer.name.length < 3) errors.push("Nome inválido");
  if (!validEmail(customer.email)) errors.push("E-mail inválido");
  if (customer.phone.length < 10 || customer.phone.length > 11) errors.push("Telefone inválido");
  if (!validCPF(customer.cpf)) errors.push("CPF inválido");
  if (address.cep.length !== 8) errors.push("CEP inválido");
  if (!address.street || !address.number || !address.district || !address.city || address.state.length !== 2) errors.push("Endereço incompleto");
  if (errors.length) return NextResponse.json({ error: errors[0], errors }, { status: 400 });

  // ---- price (server side) -------------------------------------------------
  const subtotalCents = product.priceCents * quantity;
  const discountCents = paymentMethod === "PIX" ? Math.round((subtotalCents * product.pixDiscountPct) / 100) : 0;
  const totalCents = subtotalCents - discountCents;

  try {
    const order = await prisma.$transaction(async (tx) => {
      // Atomic stock decrement: fails (count = 0) if there isn't enough stock.
      const dec = await tx.product.updateMany({
        where: { id: 1, stock: { gte: quantity } },
        data: { stock: { decrement: quantity } },
      });
      if (dec.count === 0) throw new Error("OUT_OF_STOCK");

      const cust = await tx.customer.upsert({
        where: { email: customer.email },
        update: { name: customer.name, phone: customer.phone, cpf: customer.cpf },
        create: customer,
      });
      const last = await tx.order.aggregate({ _max: { code: true } });
      const code = (last._max.code ?? 1000) + 1;

      return tx.order.create({
        data: {
          code,
          customerId: cust.id,
          color,
          size,
          quantity,
          subtotalCents,
          discountCents,
          totalCents,
          paymentMethod: paymentMethod!,
          installments,
          ...address,
        },
      });
    });

    return NextResponse.json({
      orderId: order.id,
      code: order.code,
      totalCents: order.totalCents,
      paymentMethod: order.paymentMethod,
      pix: order.paymentMethod === "PIX" ? pixForOrder(order.code, order.totalCents) : null,
    });
  } catch (e: any) {
    if (e?.message === "OUT_OF_STOCK") {
      return NextResponse.json({ error: "Estoque insuficiente para essa quantidade." }, { status: 409 });
    }
    console.error("order error", e);
    return NextResponse.json({ error: "Não foi possível criar o pedido." }, { status: 500 });
  }
}
