import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { clientIp, rateLimit } from "@/lib/auth";

/** Counts one visit per browser session (the client calls this once). Used for the conversion rate. */
export async function POST(req: Request) {
  if (!rateLimit(`visit:${clientIp(req)}`, 30, 60_000)) return NextResponse.json({ ok: true });
  await prisma.visit.create({ data: {} });
  return NextResponse.json({ ok: true });
}
