import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { guard } from "@/lib/auth";

const STATUSES = ["PENDING", "PAID", "SHIPPED", "DELIVERED", "CANCELED"];

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const denied = guard();
  if (denied) return denied;

  const { status } = (await req.json().catch(() => ({}))) as { status?: string };
  if (!status || !STATUSES.includes(status)) return NextResponse.json({ error: "Status inválido" }, { status: 400 });

  try {
    const updated = await prisma.$transaction(async (tx) => {
      const order = await tx.order.findUnique({ where: { id: params.id } });
      if (!order) throw new Error("NOT_FOUND");

      // Keep stock consistent: canceling returns units, reopening takes them again.
      if (status === "CANCELED" && order.status !== "CANCELED") {
        await tx.product.update({ where: { id: 1 }, data: { stock: { increment: order.quantity } } });
      } else if (order.status === "CANCELED" && status !== "CANCELED") {
        const dec = await tx.product.updateMany({ where: { id: 1, stock: { gte: order.quantity } }, data: { stock: { decrement: order.quantity } } });
        if (dec.count === 0) throw new Error("NO_STOCK");
      }
      return tx.order.update({ where: { id: order.id }, data: { status } });
    });
    return NextResponse.json({ ok: true, status: updated.status });
  } catch (e: any) {
    if (e?.message === "NOT_FOUND") return NextResponse.json({ error: "Pedido não encontrado" }, { status: 404 });
    if (e?.message === "NO_STOCK") return NextResponse.json({ error: "Sem estoque para reabrir este pedido" }, { status: 409 });
    console.error(e);
    return NextResponse.json({ error: "Erro ao atualizar" }, { status: 500 });
  }
}
