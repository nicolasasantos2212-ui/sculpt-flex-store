import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { guard } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const denied = guard();
  if (denied) return denied;

  const status = new URL(req.url).searchParams.get("status");
  const orders = await prisma.order.findMany({
    where: status && status !== "ALL" ? { status } : undefined,
    orderBy: { createdAt: "desc" },
    take: 300,
    include: { customer: { select: { name: true, email: true, phone: true, cpf: true } } },
  });

  return NextResponse.json(orders.map((o) => ({ ...o, createdAt: o.createdAt.toISOString(), updatedAt: o.updatedAt.toISOString() })));
}
