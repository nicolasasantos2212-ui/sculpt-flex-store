import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { guard } from "@/lib/auth";

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const denied = guard();
  if (denied) return denied;
  const { approved } = (await req.json().catch(() => ({}))) as { approved?: boolean };
  if (typeof approved !== "boolean") return NextResponse.json({ error: "Requisição inválida" }, { status: 400 });
  try {
    await prisma.review.update({ where: { id: params.id }, data: { approved } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Avaliação não encontrada" }, { status: 404 });
  }
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const denied = guard();
  if (denied) return denied;
  try {
    await prisma.review.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Avaliação não encontrada" }, { status: 404 });
  }
}
