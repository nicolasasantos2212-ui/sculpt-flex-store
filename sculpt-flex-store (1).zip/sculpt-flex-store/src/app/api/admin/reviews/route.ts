import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { guard } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const denied = guard();
  if (denied) return denied;
  const rows = await prisma.review.findMany({ orderBy: [{ approved: "asc" }, { createdAt: "desc" }], take: 200 });
  return NextResponse.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
}
