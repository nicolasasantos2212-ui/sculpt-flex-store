import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { guard } from "@/lib/auth";

export const dynamic = "force-dynamic";

const PAID_STATES = ["PAID", "SHIPPED", "DELIVERED"];
const BRT_OFFSET_MS = 3 * 3600 * 1000; // America/Sao_Paulo is UTC-3 (no DST since 2019)

/** Date key (YYYY-MM-DD) in Brasília time. */
const brtDay = (d: Date) => new Date(d.getTime() - BRT_OFFSET_MS).toISOString().slice(0, 10);

export async function GET() {
  const denied = guard();
  if (denied) return denied;

  const now = new Date();
  const nowBr = new Date(now.getTime() - BRT_OFFSET_MS);
  const startToday = new Date(Date.UTC(nowBr.getUTCFullYear(), nowBr.getUTCMonth(), nowBr.getUTCDate()) + BRT_OFFSET_MS);
  const startMonth = new Date(Date.UTC(nowBr.getUTCFullYear(), nowBr.getUTCMonth(), 1) + BRT_OFFSET_MS);
  const start14 = new Date(startToday.getTime() - 13 * 24 * 3600 * 1000);
  const since = new Date(Math.min(startMonth.getTime(), start14.getTime()));

  const [recent, allOrders, visits, pending, product] = await Promise.all([
    prisma.order.findMany({ where: { createdAt: { gte: since }, status: { in: PAID_STATES } }, select: { totalCents: true, createdAt: true } }),
    prisma.order.findMany({ select: { status: true, totalCents: true } }),
    prisma.visit.count(),
    prisma.order.count({ where: { status: "PENDING" } }),
    prisma.product.findUnique({ where: { id: 1 }, select: { stock: true } }),
  ]);

  const paid = allOrders.filter((o) => PAID_STATES.includes(o.status));
  const totalRevenueCents = paid.reduce((s, o) => s + o.totalCents, 0);
  const validOrders = allOrders.filter((o) => o.status !== "CANCELED").length;

  const sumSince = (from: Date) => recent.filter((o) => o.createdAt >= from).reduce((s, o) => s + o.totalCents, 0);
  const countSince = (from: Date) => recent.filter((o) => o.createdAt >= from).length;

  // Last 14 days revenue series (zero-filled)
  const series: { date: string; revenueCents: number; orders: number }[] = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date(startToday.getTime() - i * 24 * 3600 * 1000);
    series.push({ date: brtDay(new Date(d.getTime() + 12 * 3600 * 1000)), revenueCents: 0, orders: 0 });
  }
  for (const o of recent) {
    const key = brtDay(o.createdAt);
    const row = series.find((s) => s.date === key);
    if (row) {
      row.revenueCents += o.totalCents;
      row.orders += 1;
    }
  }

  return NextResponse.json({
    totalRevenueCents,
    totalOrders: validOrders,
    pendingOrders: pending,
    visits,
    conversionRate: visits > 0 ? (validOrders / visits) * 100 : 0,
    todayRevenueCents: sumSince(startToday),
    todayOrders: countSince(startToday),
    monthRevenueCents: sumSince(startMonth),
    monthOrders: countSince(startMonth),
    stock: product?.stock ?? 0,
    series,
  });
}
