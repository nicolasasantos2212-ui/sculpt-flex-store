import { NextResponse } from "next/server";
import { COOKIE_NAME, checkPassword, clientIp, createSessionToken, rateLimit, sessionCookieOptions } from "@/lib/auth";

export async function POST(req: Request) {
  // Brute-force protection: 8 attempts per 10 minutes per IP.
  if (!rateLimit(`login:${clientIp(req)}`, 8, 10 * 60_000)) {
    return NextResponse.json({ error: "Muitas tentativas. Tente novamente em alguns minutos." }, { status: 429 });
  }
  const { password } = (await req.json().catch(() => ({}))) as { password?: string };
  if (typeof password !== "string" || !checkPassword(password)) {
    return NextResponse.json({ error: "Senha incorreta" }, { status: 401 });
  }
  const res = NextResponse.json({ ok: true });
  res.cookies.set(COOKIE_NAME, createSessionToken(), sessionCookieOptions);
  return res;
}

export async function DELETE() {
  const res = NextResponse.json({ ok: true });
  res.cookies.set(COOKIE_NAME, "", { ...sessionCookieOptions, maxAge: 0 });
  return res;
}
