import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { guard } from "@/lib/auth";
import { getProduct } from "@/lib/product";

export const dynamic = "force-dynamic";

export async function GET() {
  const denied = guard();
  if (denied) return denied;
  return NextResponse.json(await getProduct());
}

/** Update price, stock, banner, promo deadline, WhatsApp, etc. Values are validated before saving. */
export async function PUT(req: Request) {
  const denied = guard();
  if (denied) return denied;

  const b = (await req.json().catch(() => null)) as Record<string, any> | null;
  if (!b) return NextResponse.json({ error: "Requisição inválida" }, { status: 400 });

  const data: Record<string, unknown> = {};
  const int = (v: unknown, min: number, max: number) => (Number.isInteger(v) && (v as number) >= min && (v as number) <= max ? (v as number) : null);

  if ("priceCents" in b) {
    const v = int(b.priceCents, 100, 10_000_000);
    if (v === null) return NextResponse.json({ error: "Preço inválido" }, { status: 400 });
    data.priceCents = v;
  }
  if ("oldPriceCents" in b) {
    const v = int(b.oldPriceCents, 100, 10_000_000);
    if (v === null) return NextResponse.json({ error: "Preço antigo inválido" }, { status: 400 });
    data.oldPriceCents = v;
  }
  if ("stock" in b) {
    const v = int(b.stock, 0, 100_000);
    if (v === null) return NextResponse.json({ error: "Estoque inválido" }, { status: 400 });
    data.stock = v;
  }
  if ("pixDiscountPct" in b) {
    const v = int(b.pixDiscountPct, 0, 50);
    if (v === null) return NextResponse.json({ error: "Desconto PIX inválido (0–50)" }, { status: 400 });
    data.pixDiscountPct = v;
  }
  if ("bannerText" in b) data.bannerText = String(b.bannerText).slice(0, 200);
  if ("title" in b && String(b.title).trim()) data.title = String(b.title).trim().slice(0, 200);
  if ("subtitle" in b) data.subtitle = String(b.subtitle).slice(0, 300);
  if ("whatsapp" in b) {
    const w = String(b.whatsapp).replace(/\D/g, "");
    if (w.length < 12 || w.length > 13) return NextResponse.json({ error: "WhatsApp inválido (use 55 + DDD + número)" }, { status: 400 });
    data.whatsapp = w;
  }
  if ("promoEndsAt" in b) {
    const d = new Date(b.promoEndsAt);
    if (isNaN(d.getTime())) return NextResponse.json({ error: "Data da promoção inválida" }, { status: 400 });
    data.promoEndsAt = d;
  }

  await prisma.product.update({ where: { id: 1 }, data });
  return NextResponse.json(await getProduct());
}
