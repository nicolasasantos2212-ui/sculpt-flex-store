import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { guard } from "@/lib/auth";

export const dynamic = "force-dynamic";

const PAID_STATES = ["PAID", "SHIPPED", "DELIVERED"];

export async function GET() {
  const denied = guard();
  if (denied) return denied;

  const customers = await prisma.customer.findMany({
    orderBy: { createdAt: "desc" },
    include: { orders: { orderBy: { createdAt: "desc" }, select: { code: true, status: true, totalCents: true, createdAt: true } } },
  });

  const rows = customers.map((c) => ({
    id: c.id,
    name: c.name,
    email: c.email,
    phone: c.phone,
    createdAt: c.createdAt.toISOString(),
    ordersCount: c.orders.length,
    totalSpentCents: c.orders.filter((o) => PAID_STATES.includes(o.status)).reduce((s, o) => s + o.totalCents, 0),
    lastOrderAt: c.orders[0]?.createdAt.toISOString() ?? null,
    history: c.orders.map((o) => ({ code: o.code, status: o.status, totalCents: o.totalCents, createdAt: o.createdAt.toISOString() })),
  }));

  rows.sort((a, b) => b.totalSpentCents - a.totalSpentCents);
  return NextResponse.json(rows);
}
