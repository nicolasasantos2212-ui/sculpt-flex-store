import Storefront from "@/components/Storefront";
import { getProduct, getReviews } from "@/lib/product";

// Always render fresh so stock, price and banner edits in /admin show up immediately.
export const dynamic = "force-dynamic";

export default async function Home() {
  const product = await getProduct();

  if (!product) {
    return (
      <main className="mx-auto max-w-md p-8 text-center">
        <h1 className="text-xl font-bold">Loja ainda não configurada</h1>
        <p className="mt-2 text-neutral-600">
          Rode <code className="rounded bg-neutral-100 px-1.5 py-0.5">npm run setup</code> para criar o banco de dados e o produto.
        </p>
      </main>
    );
  }

  const reviews = await getReviews();

  // Structured data for Google. Rating is only included when real approved reviews exist.
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.title,
    description: product.subtitle,
    image: product.images.slice(0, 3).map((i) => i.url),
    offers: {
      "@type": "Offer",
      priceCurrency: "BRL",
      price: (product.priceCents / 100).toFixed(2),
      availability: product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
    ...(reviews.count > 0
      ? { aggregateRating: { "@type": "AggregateRating", ratingValue: reviews.average.toFixed(1), reviewCount: reviews.count } }
      : {}),
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <Storefront product={product} reviews={reviews} />
    </>
  );
}
