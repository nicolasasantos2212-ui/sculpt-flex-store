"use client";

import { useEffect, useMemo, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Check, Copy, CreditCard, Loader2, MessageCircle, QrCode, X } from "lucide-react";
import type { PublicProduct } from "@/lib/product";
import { useStore } from "@/lib/store";
import { brl, digits, installment, maskCEP, maskCPF, maskPhone, validCPF, validEmail } from "@/lib/format";

/** Card fields are only shown once a payment gateway is configured (see README). */
const CARD_GATEWAY = !!process.env.NEXT_PUBLIC_CARD_GATEWAY;

type Method = "PIX" | "CARD";
type Result = { code: number; totalCents: number; method: Method; pix: string | null };

const EMPTY = { name: "", email: "", phone: "", cpf: "", cep: "", street: "", number: "", complement: "", district: "", city: "", state: "" };
type Form = typeof EMPTY;

export default function Checkout({ product }: { product: PublicProduct }) {
  const { color, size, qty, closeCheckout, clearCart, setQty } = useStore();
  const [f, setF] = useState<Form>(EMPTY);
  const [errors, setErrors] = useState<Partial<Record<keyof Form, string>>>({});
  const [method, setMethod] = useState<Method>("PIX");
  const [inst, setInst] = useState(1);
  const [cepLoading, setCepLoading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [serverError, setServerError] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const [copied, setCopied] = useState(false);

  // ---- prices (display only; the server recomputes everything) ---------------
  const subtotal = product.priceCents * qty;
  const discount = method === "PIX" ? Math.round((subtotal * product.pixDiscountPct) / 100) : 0;
  const total = subtotal - discount;

  // ---- modal behavior: lock scroll + ESC ------------------------------------
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closeCheckout();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [closeCheckout]);

  // ---- CEP auto-fill via ViaCEP (public API). Fields stay editable if it fails. --
  useEffect(() => {
    const c = digits(f.cep);
    if (c.length !== 8) return;
    const ctrl = new AbortController();
    setCepLoading(true);
    fetch(`https://viacep.com.br/ws/${c}/json/`, { signal: ctrl.signal })
      .then((r) => r.json())
      .then((d) => {
        if (d.erro) return;
        setF((p) => ({ ...p, street: d.logradouro || p.street, district: d.bairro || p.district, city: d.localidade || p.city, state: d.uf || p.state }));
      })
      .catch(() => {})
      .finally(() => setCepLoading(false));
    return () => ctrl.abort();
  }, [f.cep]);

  const set = (k: keyof Form, mask?: (v: string) => string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = mask ? mask(e.target.value) : e.target.value;
    setF((p) => ({ ...p, [k]: v }));
    setErrors((p) => ({ ...p, [k]: undefined }));
  };

  const installments = useMemo(() => Array.from({ length: 12 }, (_, i) => i + 1), []);

  const validate = () => {
    const e: Partial<Record<keyof Form, string>> = {};
    if (f.name.trim().length < 3) e.name = "Informe seu nome completo";
    if (!validEmail(f.email)) e.email = "E-mail inválido";
    if (![10, 11].includes(digits(f.phone).length)) e.phone = "Telefone inválido";
    if (!validCPF(f.cpf)) e.cpf = "CPF inválido";
    if (digits(f.cep).length !== 8) e.cep = "CEP inválido";
    if (!f.street.trim()) e.street = "Informe a rua";
    if (!f.number.trim()) e.number = "Informe o número";
    if (!f.district.trim()) e.district = "Informe o bairro";
    if (!f.city.trim()) e.city = "Informe a cidade";
    if (f.state.trim().length !== 2) e.state = "UF";
    return e;
  };

  const submit = async () => {
    setServerError("");
    const e = validate();
    setErrors(e);
    const first = Object.keys(e)[0];
    if (first) {
      document.getElementById(`ck-${first}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
      document.getElementById(`ck-${first}`)?.focus();
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          color,
          size,
          quantity: qty,
          paymentMethod: method,
          installments: method === "CARD" ? inst : 1,
          customer: { name: f.name, email: f.email, phone: f.phone, cpf: f.cpf },
          address: { cep: f.cep, street: f.street, number: f.number, complement: f.complement, district: f.district, city: f.city, state: f.state },
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setServerError(data.error || "Não foi possível finalizar o pedido.");
        return;
      }
      setResult({ code: data.code, totalCents: data.totalCents, method, pix: data.pix });
      clearCart();
    } catch {
      setServerError("Falha de conexão. Verifique sua internet e tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  const copyPix = async () => {
    if (!result?.pix) return;
    try {
      await navigator.clipboard.writeText(result.pix);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      /* clipboard blocked: user can long-press the text */
    }
  };

  const waLink = (msg: string) => `https://wa.me/${product.whatsapp}?text=${encodeURIComponent(msg)}`;
  const field = (k: keyof Form) => `input ${errors[k] ? "input-error" : ""}`;
  const Err = ({ k }: { k: keyof Form }) => (errors[k] ? <p className="mt-1 text-xs font-semibold text-red-600">{errors[k]}</p> : null);

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/60 sm:items-center" onClick={closeCheckout}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Finalizar compra"
        className="flex max-h-[96dvh] w-full max-w-2xl flex-col rounded-t-3xl bg-white sm:max-h-[92dvh] sm:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-neutral-200 px-5 py-3">
          <h2 className="text-lg font-black">{result ? "Pedido recebido" : "Finalizar compra"}</h2>
          <button onClick={closeCheckout} aria-label="Fechar" className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-neutral-100">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="overflow-y-auto px-5 py-4">
          {result ? (
            <Confirmation result={result} copied={copied} onCopy={copyPix} waLink={waLink} onClose={closeCheckout} />
          ) : (
            <>
              {/* Order summary */}
              <div className="rounded-2xl bg-neutral-50 p-4 text-sm">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="font-bold">{product.title}</p>
                    <p className="text-neutral-500">
                      {color} · Tamanho {size}
                    </p>
                  </div>
                  <div className="flex items-center rounded-lg border border-neutral-300 bg-white">
                    <button onClick={() => setQty(qty - 1)} className="h-9 w-9 font-bold" aria-label="Diminuir quantidade">
                      −
                    </button>
                    <span className="w-6 text-center font-bold">{qty}</span>
                    <button onClick={() => setQty(Math.min(qty + 1, Math.max(1, product.stock)))} className="h-9 w-9 font-bold" aria-label="Aumentar quantidade">
                      +
                    </button>
                  </div>
                </div>
                <dl className="mt-3 space-y-1 border-t border-neutral-200 pt-3">
                  <Row label="Subtotal" value={brl(subtotal)} />
                  {discount > 0 && <Row label={`Desconto PIX (${product.pixDiscountPct}%)`} value={`− ${brl(discount)}`} accent />}
                  <Row label="Frete" value="Grátis" accent />
                  <Row label="Total" value={brl(total)} strong />
                </dl>
              </div>

              {/* Customer */}
              <h3 className="mb-2 mt-6 font-black">1. Seus dados</h3>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <input id="ck-name" className={field("name")} placeholder="Nome completo" autoComplete="name" value={f.name} onChange={set("name")} />
                  <Err k="name" />
                </div>
                <div>
                  <input id="ck-email" className={field("email")} type="email" inputMode="email" placeholder="E-mail" autoComplete="email" value={f.email} onChange={set("email")} />
                  <Err k="email" />
                </div>
                <div>
                  <input id="ck-phone" className={field("phone")} inputMode="tel" placeholder="WhatsApp / Telefone" autoComplete="tel" value={f.phone} onChange={set("phone", maskPhone)} />
                  <Err k="phone" />
                </div>
                <div className="sm:col-span-2">
                  <input id="ck-cpf" className={field("cpf")} inputMode="numeric" placeholder="CPF" value={f.cpf} onChange={set("cpf", maskCPF)} />
                  <Err k="cpf" />
                </div>
              </div>

              {/* Address */}
              <h3 className="mb-2 mt-6 font-black">2. Endereço de entrega</h3>
              <div className="grid grid-cols-6 gap-3">
                <div className="relative col-span-6 sm:col-span-2">
                  <input id="ck-cep" className={field("cep")} inputMode="numeric" placeholder="CEP" autoComplete="postal-code" value={f.cep} onChange={set("cep", maskCEP)} />
                  {cepLoading && <Loader2 className="absolute right-3 top-3.5 h-5 w-5 animate-spin text-neutral-400" />}
                  <Err k="cep" />
                </div>
                <div className="col-span-6 sm:col-span-4">
                  <input id="ck-street" className={field("street")} placeholder="Rua / Avenida" autoComplete="address-line1" value={f.street} onChange={set("street")} />
                  <Err k="street" />
                </div>
                <div className="col-span-2">
                  <input id="ck-number" className={field("number")} placeholder="Número" value={f.number} onChange={set("number")} />
                  <Err k="number" />
                </div>
                <div className="col-span-4">
                  <input className="input" placeholder="Complemento (opcional)" value={f.complement} onChange={set("complement")} />
                </div>
                <div className="col-span-6 sm:col-span-2">
                  <input id="ck-district" className={field("district")} placeholder="Bairro" value={f.district} onChange={set("district")} />
                  <Err k="district" />
                </div>
                <div className="col-span-4 sm:col-span-3">
                  <input id="ck-city" className={field("city")} placeholder="Cidade" value={f.city} onChange={set("city")} />
                  <Err k="city" />
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <input id="ck-state" className={field("state")} placeholder="UF" maxLength={2} value={f.state} onChange={set("state", (v) => v.toUpperCase().slice(0, 2))} />
                  <Err k="state" />
                </div>
              </div>

              {/* Payment */}
              <h3 className="mb-2 mt-6 font-black">3. Pagamento</h3>
              <div className="grid grid-cols-2 gap-2" role="tablist">
                <PayTab active={method === "PIX"} onClick={() => setMethod("PIX")} icon={<QrCode className="h-5 w-5" />} title="PIX" badge={`${product.pixDiscountPct}% OFF`} />
                <PayTab active={method === "CARD"} onClick={() => setMethod("CARD")} icon={<CreditCard className="h-5 w-5" />} title="Cartão" badge="até 12x" />
              </div>

              {method === "PIX" ? (
                <p className="mt-3 rounded-xl bg-lime/40 p-3 text-sm">
                  Após confirmar, você recebe o <b>QR Code e o código Copia e Cola</b>. O pedido é liberado assim que o pagamento for confirmado.
                </p>
              ) : (
                <div className="mt-3 space-y-3">
                  <select className="input" value={inst} onChange={(e) => setInst(Number(e.target.value))} aria-label="Parcelas">
                    {installments.map((n) => (
                      <option key={n} value={n}>
                        {n}x de {brl(installment(total, n))} sem juros
                      </option>
                    ))}
                  </select>
                  {CARD_GATEWAY ? (
                    <CardFields />
                  ) : (
                    <p className="rounded-xl bg-neutral-100 p-3 text-sm">
                      Por segurança, <b>não pedimos os dados do cartão aqui</b>. Ao confirmar, enviamos um link de pagamento seguro pelo WhatsApp.
                    </p>
                  )}
                </div>
              )}

              {serverError && <p className="mt-4 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700">{serverError}</p>}
            </>
          )}
        </div>

        {!result && (
          <div className="border-t border-neutral-200 p-4" style={{ paddingBottom: "max(1rem, env(safe-area-inset-bottom))" }}>
            <button onClick={submit} disabled={loading} className="btn-cta disabled:opacity-60">
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : null}
              {loading ? "Processando..." : `Confirmar pedido · ${brl(total)}`}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, strong, accent }: { label: string; value: string; strong?: boolean; accent?: boolean }) {
  return (
    <div className={`flex justify-between ${strong ? "pt-1 text-base font-black" : ""} ${accent ? "font-semibold text-green-700" : ""}`}>
      <dt>{label}</dt>
      <dd>{value}</dd>
    </div>
  );
}

function PayTab({ active, onClick, icon, title, badge }: { active: boolean; onClick: () => void; icon: React.ReactNode; title: string; badge: string }) {
  return (
    <button
      role="tab"
      aria-selected={active}
      onClick={onClick}
      className={`flex h-14 items-center justify-center gap-2 rounded-xl border-2 font-bold transition ${active ? "border-ink bg-ink text-white" : "border-neutral-300"}`}
    >
      {icon}
      {title}
      <span className={`rounded-md px-1.5 py-0.5 text-[10px] font-extrabold ${active ? "bg-lime text-ink" : "bg-neutral-100"}`}>{badge}</span>
    </button>
  );
}

/**
 * UI only. When you integrate a gateway, replace these inputs with the gateway's
 * hosted fields / tokenization SDK so raw card data never touches your server.
 */
function CardFields() {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <input className="input sm:col-span-2" inputMode="numeric" placeholder="Número do cartão" autoComplete="cc-number" />
      <input className="input sm:col-span-2" placeholder="Nome impresso no cartão" autoComplete="cc-name" />
      <input className="input" inputMode="numeric" placeholder="Validade (MM/AA)" autoComplete="cc-exp" />
      <input className="input" inputMode="numeric" placeholder="CVV" autoComplete="cc-csc" />
    </div>
  );
}

function Confirmation({ result, copied, onCopy, waLink, onClose }: { result: Result; copied: boolean; onCopy: () => void; waLink: (m: string) => string; onClose: () => void }) {
  const msg = `Olá! Fiz o pedido #${result.code} (${brl(result.totalCents)}) e quero acompanhar.`;
  return (
    <div className="text-center">
      <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-lime">
        <Check className="h-8 w-8" />
      </div>
      <h3 className="mt-3 text-xl font-black">Pedido #{result.code} recebido!</h3>
      <p className="text-neutral-600">
        Total: <b>{brl(result.totalCents)}</b>
      </p>

      {result.method === "PIX" ? (
        result.pix ? (
          <div className="mt-5">
            <p className="text-sm font-semibold">Pague com PIX para confirmar seu pedido:</p>
            <div className="mx-auto mt-3 inline-block rounded-2xl border border-neutral-200 bg-white p-3">
              <QRCodeSVG value={result.pix} size={200} level="M" />
            </div>
            <textarea readOnly value={result.pix} onFocus={(e) => e.currentTarget.select()} className="input mt-3 h-24 text-xs" aria-label="Código PIX Copia e Cola" />
            <button onClick={onCopy} className="btn-cta mt-3">
              {copied ? <Check className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
              {copied ? "Código copiado!" : "Copiar código PIX"}
            </button>
            <p className="mt-3 text-xs text-neutral-500">Abra o app do seu banco, escolha PIX → Pix Copia e Cola (ou leia o QR Code). A confirmação é feita manualmente pela nossa equipe.</p>
          </div>
        ) : (
          <p className="mt-5 rounded-xl bg-neutral-100 p-4 text-sm">Vamos enviar a chave PIX e as instruções de pagamento pelo WhatsApp em instantes.</p>
        )
      ) : (
        <p className="mt-5 rounded-xl bg-neutral-100 p-4 text-sm">Enviaremos o link seguro de pagamento no cartão pelo WhatsApp em instantes.</p>
      )}

      <a href={waLink(msg)} target="_blank" rel="noopener noreferrer" className="mt-4 flex h-12 items-center justify-center gap-2 rounded-xl border-2 border-ink font-bold">
        <MessageCircle className="h-5 w-5 text-green-600" /> Falar no WhatsApp
      </a>
      <button onClick={onClose} className="mt-3 h-11 text-sm font-semibold text-neutral-500 underline">
        Voltar à loja
      </button>
    </div>
  );
}
