"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { FAQ } from "@/content/copy";

export default function Faq() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section className="mx-auto max-w-3xl px-4 py-12">
      <h2 className="text-2xl font-black sm:text-3xl">Perguntas frequentes</h2>
      <div className="mt-6 divide-y divide-neutral-200 rounded-2xl border border-neutral-200">
        {FAQ.map((item, i) => {
          const isOpen = open === i;
          return (
            <div key={item.q}>
              <button
                onClick={() => setOpen(isOpen ? null : i)}
                aria-expanded={isOpen}
                aria-controls={`faq-${i}`}
                className="flex min-h-14 w-full items-center justify-between gap-3 px-4 py-3 text-left font-bold"
              >
                {item.q}
                <ChevronDown className={`h-5 w-5 shrink-0 transition-transform ${isOpen ? "rotate-180" : ""}`} />
              </button>
              <div id={`faq-${i}`} hidden={!isOpen} className="px-4 pb-4 text-neutral-600">
                {item.a}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
