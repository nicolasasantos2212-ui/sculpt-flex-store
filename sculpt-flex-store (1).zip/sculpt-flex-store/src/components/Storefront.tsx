"use client";

import { useEffect } from "react";
import type { PublicProduct, PublicReview } from "@/lib/product";
import { useStore } from "@/lib/store";
import Header from "./Header";
import Gallery from "./Gallery";
import BuyBox from "./BuyBox";
import Features from "./Features";
import Reviews from "./Reviews";
import Urgency from "./Urgency";
import Faq from "./Faq";
import Footer from "./Footer";
import StickyBuy from "./StickyBuy";
import SizeGuide from "./SizeGuide";
import Checkout from "./Checkout";

type Props = {
  product: PublicProduct;
  reviews: { reviews: PublicReview[]; average: number; count: number };
};

/** Page composition. Keep sections small and independent so they're easy to reorder. */
export default function Storefront({ product, reviews }: Props) {
  const { color, init, checkoutOpen, sizeGuideOpen } = useStore();

  useEffect(() => {
    init(product.colors[0]?.name ?? "");
  }, [init, product.colors]);

  // Count one visit per browser session (powers the conversion rate in /admin).
  useEffect(() => {
    try {
      if (sessionStorage.getItem("sf_visit")) return;
      sessionStorage.setItem("sf_visit", "1");
    } catch {
      /* storage blocked: skip */
    }
    fetch("/api/visit", { method: "POST", keepalive: true }).catch(() => {});
  }, []);

  return (
    <>
      <Header product={product} />

      <main>
        <section className="mx-auto grid max-w-6xl gap-6 px-4 pb-10 pt-4 lg:grid-cols-2 lg:gap-12 lg:pt-8">
          <Gallery images={product.images} color={color} />
          <BuyBox product={product} rating={{ average: reviews.average, count: reviews.count }} />
        </section>

        <Features />
        <Reviews initial={reviews.reviews} average={reviews.average} count={reviews.count} />
        <Urgency product={product} />
        <Faq />
      </main>

      <Footer product={product} />
      <StickyBuy product={product} />

      {sizeGuideOpen && <SizeGuide />}
      {checkoutOpen && <Checkout product={product} />}
    </>
  );
}
