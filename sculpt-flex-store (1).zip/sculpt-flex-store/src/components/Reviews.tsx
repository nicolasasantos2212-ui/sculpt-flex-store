"use client";

import { useMemo, useState } from "react";
import { BadgeCheck, Camera, Star } from "lucide-react";
import type { PublicReview } from "@/lib/product";
import { dateBR } from "@/lib/format";

type Filter = "all" | "5" | "4" | "low" | "photo";

const Stars = ({ n, size = "h-4 w-4" }: { n: number; size?: string }) => (
  <span className="flex text-amber-400" aria-label={`${n} de 5 estrelas`}>
    {[1, 2, 3, 4, 5].map((i) => (
      <Star key={i} className={`${size} ${i <= n ? "fill-current" : "text-neutral-300"}`} />
    ))}
  </span>
);

/** Downscales the picked photo in the browser so uploads stay small (~100 KB). */
async function compress(file: File): Promise<string> {
  const bmp = await createImageBitmap(file);
  const scale = Math.min(1, 800 / Math.max(bmp.width, bmp.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bmp.width * scale);
  canvas.height = Math.round(bmp.height * scale);
  canvas.getContext("2d")!.drawImage(bmp, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.7);
}

export default function Reviews({ initial, average, count }: { initial: PublicReview[]; average: number; count: number }) {
  const [filter, setFilter] = useState<Filter>("all");
  const [visible, setVisible] = useState(6);
  const [zoom, setZoom] = useState<string | null>(null);

  const list = useMemo(() => {
    return initial.filter((r) => {
      if (filter === "5") return r.rating === 5;
      if (filter === "4") return r.rating === 4;
      if (filter === "low") return r.rating <= 3;
      if (filter === "photo") return !!r.photo;
      return true;
    });
  }, [initial, filter]);

  const chips: { id: Filter; label: string }[] = [
    { id: "all", label: "Todas" },
    { id: "5", label: "5 ★" },
    { id: "4", label: "4 ★" },
    { id: "low", label: "3 ★ ou menos" },
    { id: "photo", label: "Com fotos" },
  ];

  return (
    <section id="avaliacoes" className="mx-auto max-w-6xl scroll-mt-28 px-4 py-12">
      <h2 className="text-2xl font-black sm:text-3xl">Avaliações das clientes</h2>

      {count > 0 ? (
        <div className="mt-3 flex items-center gap-3">
          <span className="text-4xl font-black">{average.toFixed(1)}</span>
          <div>
            <Stars n={Math.round(average)} size="h-5 w-5" />
            <p className="text-sm text-neutral-500">{count.toLocaleString("pt-BR")} avaliações</p>
          </div>
        </div>
      ) : (
        <p className="mt-2 text-neutral-500">Ainda não há avaliações publicadas. Seja a primeira a compartilhar sua experiência!</p>
      )}

      {count > 0 && (
        <div className="no-scrollbar mt-5 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label="Filtrar avaliações">
          {chips.map((c) => (
            <button
              key={c.id}
              role="tab"
              aria-selected={filter === c.id}
              onClick={() => {
                setFilter(c.id);
                setVisible(6);
              }}
              className={`inline-flex h-10 shrink-0 items-center gap-1.5 rounded-full border px-4 text-sm font-semibold ${
                filter === c.id ? "border-ink bg-ink text-white" : "border-neutral-300 bg-white"
              }`}
            >
              {c.id === "photo" && <Camera className="h-4 w-4" />}
              {c.label}
            </button>
          ))}
        </div>
      )}

      <div className="mt-5 grid gap-4 md:grid-cols-2">
        {list.slice(0, visible).map((r) => (
          <article key={r.id} className="rounded-2xl border border-neutral-200 p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-lime font-black">{r.name.charAt(0).toUpperCase()}</div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-bold">{r.name}</p>
                <p className="text-xs text-neutral-500">{dateBR(r.createdAt)}</p>
              </div>
              <Stars n={r.rating} />
            </div>
            {r.verified && (
              <p className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-green-700">
                <BadgeCheck className="h-4 w-4" /> Compra verificada
              </p>
            )}
            <p className="mt-2 text-neutral-700">{r.comment}</p>
            {r.photo && (
              <button onClick={() => setZoom(r.photo)} className="mt-3 block" aria-label="Ampliar foto da cliente">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={r.photo} alt={`Foto enviada por ${r.name}`} loading="lazy" className="h-24 w-24 rounded-xl object-cover" />
              </button>
            )}
          </article>
        ))}
      </div>

      {list.length === 0 && count > 0 && <p className="mt-4 text-neutral-500">Nenhuma avaliação para este filtro.</p>}
      {list.length > visible && (
        <button onClick={() => setVisible((v) => v + 6)} className="mt-5 h-12 w-full rounded-xl border-2 border-ink font-bold sm:w-auto sm:px-8">
          Ver mais avaliações
        </button>
      )}

      <ReviewForm />

      {zoom && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/80 p-4" onClick={() => setZoom(null)} role="dialog" aria-modal="true">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={zoom} alt="Foto ampliada" className="max-h-full max-w-full rounded-xl" />
        </div>
      )}
    </section>
  );
}

function ReviewForm() {
  const [rating, setRating] = useState(0);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [comment, setComment] = useState("");
  const [photo, setPhoto] = useState<string | null>(null);
  const [state, setState] = useState<"idle" | "sending" | "done">("idle");
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!rating) return setError("Escolha de 1 a 5 estrelas.");
    setState("sending");
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, rating, comment, photo }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erro ao enviar");
      setState("done");
    } catch (err: any) {
      setError(err.message || "Erro ao enviar");
      setState("idle");
    }
  };

  if (state === "done") {
    return (
      <div className="mt-10 rounded-2xl bg-lime p-5 font-bold">
        Obrigado pela avaliação! Ela será publicada após a moderação.
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="mt-10 rounded-2xl bg-neutral-50 p-5">
      <h3 className="text-lg font-black">Já comprou? Deixe sua avaliação</h3>
      <div className="mt-3 flex gap-1" role="radiogroup" aria-label="Nota">
        {[1, 2, 3, 4, 5].map((n) => (
          <button type="button" key={n} onClick={() => setRating(n)} aria-label={`${n} estrelas`} aria-checked={rating === n} role="radio" className="p-1">
            <Star className={`h-8 w-8 ${n <= rating ? "fill-amber-400 text-amber-400" : "text-neutral-300"}`} />
          </button>
        ))}
      </div>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <input className="input" placeholder="Seu nome" value={name} onChange={(e) => setName(e.target.value)} required maxLength={60} />
        <input className="input" type="email" placeholder="Seu e-mail (não será exibido)" value={email} onChange={(e) => setEmail(e.target.value)} required />
      </div>
      <textarea className="input mt-3 min-h-28" placeholder="Conte como foi sua experiência" value={comment} onChange={(e) => setComment(e.target.value)} required minLength={5} maxLength={1000} />
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <label className="inline-flex h-11 cursor-pointer items-center gap-2 rounded-xl border border-neutral-300 bg-white px-4 text-sm font-semibold">
          <Camera className="h-4 w-4" /> {photo ? "Trocar foto" : "Adicionar foto"}
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                setPhoto(await compress(f));
              } catch {
                setError("Não foi possível ler essa imagem.");
              }
            }}
          />
        </label>
        {photo && (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={photo} alt="Prévia da foto" className="h-11 w-11 rounded-lg object-cover" />
        )}
      </div>
      {error && <p className="mt-3 text-sm font-semibold text-red-600">{error}</p>}
      <button disabled={state === "sending"} className="mt-4 h-12 w-full rounded-xl bg-ink font-bold text-white disabled:opacity-60 sm:w-auto sm:px-8">
        {state === "sending" ? "Enviando..." : "Enviar avaliação"}
      </button>
    </form>
  );
}
