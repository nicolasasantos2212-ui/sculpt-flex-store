"use client";

import { useEffect } from "react";
import { X } from "lucide-react";
import { SIZE_GUIDE } from "@/content/copy";
import { useStore } from "@/lib/store";

export default function SizeGuide() {
  const { setSizeGuide, setSize, size } = useStore();
  const close = () => setSizeGuide(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/60 sm:items-center" onClick={close}>
      <div role="dialog" aria-modal="true" aria-label="Guia de medidas" className="w-full max-w-lg rounded-t-3xl bg-white p-5 sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-black">Guia de medidas</h2>
          <button onClick={close} aria-label="Fechar" className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-neutral-100">
            <X className="h-5 w-5" />
          </button>
        </div>
        <p className="mt-1 text-sm text-neutral-500">Medidas do corpo em centímetros. Toque em uma linha para escolher o tamanho.</p>
        <table className="mt-4 w-full text-center text-sm">
          <thead>
            <tr className="border-b border-neutral-200 text-neutral-500">
              <th className="py-2">Tam.</th>
              <th>Busto</th>
              <th>Cintura</th>
              <th>Quadril</th>
            </tr>
          </thead>
          <tbody>
            {SIZE_GUIDE.map((r) => (
              <tr
                key={r.size}
                onClick={() => {
                  setSize(r.size);
                  close();
                }}
                className={`cursor-pointer border-b border-neutral-100 ${size === r.size ? "bg-lime font-bold" : "hover:bg-neutral-50"}`}
              >
                <td className="py-3 font-black">{r.size}</td>
                <td>{r.bust}</td>
                <td>{r.waist}</td>
                <td>{r.hip}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="mt-4 text-xs text-neutral-500">Entre dois tamanhos? Escolha o maior para mais conforto ou o menor para mais compressão.</p>
      </div>
    </div>
  );
}
