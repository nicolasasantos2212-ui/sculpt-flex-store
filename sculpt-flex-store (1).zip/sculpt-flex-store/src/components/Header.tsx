"use client";

import { MessageCircle, ShoppingBag } from "lucide-react";
import type { PublicProduct } from "@/lib/product";
import { scrollToBuy, useStore } from "@/lib/store";
import { BRAND } from "@/content/copy";

/** Sticky announcement bar (text editable in /admin) + minimal header. */
export default function Header({ product }: { product: PublicProduct }) {
  const { inCart, qty, openCheckout } = useStore();
  const wa = `https://wa.me/${product.whatsapp}?text=${encodeURIComponent("Olá! Tenho uma dúvida sobre o macacão Sculpt & Flex.")}`;

  return (
    <div className="sticky top-0 z-40">
      {product.bannerText && (
        <div className="bg-ink px-3 py-2 text-center text-xs font-bold leading-snug text-lime sm:text-sm">{product.bannerText}</div>
      )}
      <header className="border-b border-neutral-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
          <span className="text-lg font-black tracking-tight">{BRAND}</span>
          <div className="flex items-center gap-1">
            <a
              href={wa}
              target="_blank"
              rel="noopener noreferrer"
              className="flex h-11 items-center gap-1.5 rounded-full px-3 text-sm font-semibold hover:bg-neutral-100"
              aria-label="Falar no WhatsApp"
            >
              <MessageCircle className="h-5 w-5 text-green-600" />
              <span className="hidden sm:inline">WhatsApp</span>
            </a>
            <button
              onClick={() => (inCart ? openCheckout() : scrollToBuy())}
              className="relative flex h-11 w-11 items-center justify-center rounded-full hover:bg-neutral-100"
              aria-label={inCart ? `Abrir carrinho com ${qty} item(ns)` : "Ir para a compra"}
            >
              <ShoppingBag className="h-6 w-6" />
              {inCart && (
                <span className="absolute right-1 top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-rose px-1 text-[11px] font-bold text-white">
                  {qty}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>
    </div>
  );
}
