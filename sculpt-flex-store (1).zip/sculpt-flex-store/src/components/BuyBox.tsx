"use client";

import { useState } from "react";
import { BadgeCheck, Lock, Minus, Plus, Ruler, ShieldCheck, Star, Truck } from "lucide-react";
import type { PublicProduct } from "@/lib/product";
import { useStore } from "@/lib/store";
import { brl, installment } from "@/lib/format";
import Countdown from "./Countdown";

type Props = { product: PublicProduct; rating: { average: number; count: number } };

export default function BuyBox({ product, rating }: Props) {
  const { color, size, qty, setColor, setSize, setQty, buyNow, setSizeGuide } = useStore();
  const [sizeError, setSizeError] = useState(false);

  const soldOut = product.stock <= 0;
  const maxQty = Math.max(1, Math.min(5, product.stock));
  const pixPrice = Math.round(product.priceCents * (1 - product.pixDiscountPct / 100));
  const off = Math.round((1 - product.priceCents / product.oldPriceCents) * 100);

  const handleBuy = () => {
    if (!size) {
      setSizeError(true);
      document.getElementById("tamanhos")?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    buyNow();
  };

  return (
    <div id="comprar" className="scroll-mt-28">
      <h1 className="text-2xl font-black leading-tight sm:text-3xl">{product.title}</h1>

      {rating.count > 0 ? (
        <a href="#avaliacoes" className="mt-2 inline-flex items-center gap-2 text-sm">
          <span className="flex text-amber-400" aria-hidden>
            {[1, 2, 3, 4, 5].map((n) => (
              <Star key={n} className={`h-4 w-4 ${n <= Math.round(rating.average) ? "fill-current" : "text-neutral-300"}`} />
            ))}
          </span>
          <span className="font-bold">{rating.average.toFixed(1)}/5</span>
          <span className="text-neutral-500 underline">({rating.count.toLocaleString("pt-BR")} avaliações)</span>
        </a>
      ) : (
        <a href="#avaliacoes" className="mt-2 inline-block text-sm text-neutral-500 underline">
          Seja a primeira a avaliar este produto
        </a>
      )}

      <p className="mt-2 text-neutral-600">{product.subtitle}</p>

      {/* Price */}
      <div className="mt-4 rounded-2xl bg-neutral-50 p-4">
        <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
          <span className="text-neutral-400 line-through">{brl(product.oldPriceCents)}</span>
          <span className="text-4xl font-black">{brl(product.priceCents)}</span>
          {off > 0 && <span className="rounded-md bg-rose px-2 py-0.5 text-xs font-extrabold text-white">-{off}%</span>}
        </div>
        <p className="mt-1 text-sm text-neutral-600">
          ou 12x de <b>{brl(installment(product.priceCents, 12))}</b> sem juros
        </p>
        {product.pixDiscountPct > 0 && (
          <p className="mt-2 inline-flex items-center gap-2 rounded-lg bg-lime px-3 py-1.5 text-sm font-extrabold text-ink">
            {product.pixDiscountPct}% OFF NO PIX: {brl(pixPrice)}
          </p>
        )}
      </div>

      {/* Color */}
      <div className="mt-5">
        <div className="mb-2 text-sm font-bold">
          Cor: <span className="font-medium text-neutral-600">{color}</span>
        </div>
        <div className="flex flex-wrap gap-3" role="radiogroup" aria-label="Cor">
          {product.colors.map((c) => (
            <button
              key={c.name}
              role="radio"
              aria-checked={color === c.name}
              aria-label={c.name}
              onClick={() => setColor(c.name)}
              className={`h-11 w-11 rounded-full border-2 p-0.5 transition ${color === c.name ? "border-ink" : "border-neutral-200"}`}
            >
              <span className="block h-full w-full rounded-full border border-black/10" style={{ background: c.hex }} />
            </button>
          ))}
        </div>
      </div>

      {/* Size */}
      <div id="tamanhos" className="mt-5">
        <div className="mb-2 flex items-center justify-between text-sm">
          <span className="font-bold">
            Tamanho: <span className="font-medium text-neutral-600">{size || "selecione"}</span>
          </span>
          <button onClick={() => setSizeGuide(true)} className="inline-flex items-center gap-1 font-semibold underline">
            <Ruler className="h-4 w-4" /> Guia de medidas
          </button>
        </div>
        <div className="flex gap-2" role="radiogroup" aria-label="Tamanho">
          {product.sizes.map((s) => (
            <button
              key={s}
              role="radio"
              aria-checked={size === s}
              onClick={() => {
                setSize(s);
                setSizeError(false);
              }}
              className={`h-12 min-w-14 flex-1 rounded-xl border-2 px-4 font-bold transition sm:flex-none ${
                size === s ? "border-ink bg-ink text-white" : "border-neutral-300 bg-white hover:border-ink"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
        {sizeError && <p className="mt-2 text-sm font-semibold text-red-600">Escolha um tamanho para continuar.</p>}
      </div>

      {/* Quantity */}
      <div className="mt-5 flex items-center gap-3">
        <span className="text-sm font-bold">Quantidade</span>
        <div className="flex items-center rounded-xl border border-neutral-300">
          <button onClick={() => setQty(Math.max(1, qty - 1))} aria-label="Diminuir" className="flex h-11 w-11 items-center justify-center">
            <Minus className="h-4 w-4" />
          </button>
          <span className="w-8 text-center font-bold tabular-nums">{qty}</span>
          <button onClick={() => setQty(Math.min(maxQty, qty + 1))} aria-label="Aumentar" className="flex h-11 w-11 items-center justify-center">
            <Plus className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Urgency: real stock + real deadline */}
      {!soldOut && product.stock <= 30 && (
        <p className="mt-5 flex items-center gap-2 text-sm font-bold text-rose">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-rose opacity-75" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-rose" />
          </span>
          Restam apenas {product.stock} unidades com Frete Grátis!
        </p>
      )}
      <Countdown endsAt={product.promoEndsAt} className="mt-3" />

      <button onClick={handleBuy} disabled={soldOut} className={`btn-cta mt-5 ${soldOut ? "cursor-not-allowed opacity-50" : "animate-pulseCta"}`}>
        {soldOut ? "Esgotado" : "Comprar agora com frete grátis"}
      </button>

      <ul className="mt-5 grid grid-cols-3 gap-2 text-center text-[11px] font-semibold leading-tight sm:text-xs">
        {[
          { Icon: Lock, t: "Compra 100% Segura" },
          { Icon: ShieldCheck, t: "Garantia de 7 Dias" },
          { Icon: Truck, t: "Entrega Rastreada" },
        ].map(({ Icon, t }) => (
          <li key={t} className="flex flex-col items-center gap-1 rounded-xl border border-neutral-200 px-1 py-3">
            <Icon className="h-5 w-5" />
            {t}
          </li>
        ))}
      </ul>
      <p className="mt-3 flex items-center gap-1.5 text-xs text-neutral-500">
        <BadgeCheck className="h-4 w-4" /> Frete grátis para todo o Brasil.
      </p>
    </div>
  );
}
