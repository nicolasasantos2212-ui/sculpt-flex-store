"use client";

import { useEffect, useState } from "react";

const pad = (n: number) => String(n).padStart(2, "0");

/**
 * Counts down to the REAL promo deadline stored in the database (editable in /admin).
 * It never resets by itself: fake/evergreen timers are misleading advertising under
 * Brazilian consumer law. When the deadline passes, the timer disappears.
 */
export default function Countdown({ endsAt, className = "" }: { endsAt: string; className?: string }) {
  const [left, setLeft] = useState<number | null>(null);

  useEffect(() => {
    const end = new Date(endsAt).getTime();
    const tick = () => setLeft(Math.max(0, end - Date.now()));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [endsAt]);

  if (left === null || left <= 0) return null; // also avoids hydration mismatch

  const s = Math.floor(left / 1000);
  const days = Math.floor(s / 86400);
  const parts = [
    ...(days > 0 ? [{ v: days, l: "dias" }] : []),
    { v: Math.floor((s % 86400) / 3600), l: "horas" },
    { v: Math.floor((s % 3600) / 60), l: "min" },
    { v: s % 60, l: "seg" },
  ];

  return (
    <div className={`flex items-center gap-2 ${className}`} role="timer" aria-label="Tempo restante da promoção">
      {parts.map((p, idx) => (
        <div key={p.l} className="flex items-center gap-2">
          <div className="min-w-[3.25rem] rounded-lg bg-ink px-2 py-1.5 text-center text-white">
            <div className="text-xl font-black tabular-nums leading-none">{pad(p.v)}</div>
            <div className="mt-0.5 text-[10px] uppercase tracking-wide text-neutral-400">{p.l}</div>
          </div>
          {idx < parts.length - 1 && <span className="font-bold text-neutral-400">:</span>}
        </div>
      ))}
    </div>
  );
}
