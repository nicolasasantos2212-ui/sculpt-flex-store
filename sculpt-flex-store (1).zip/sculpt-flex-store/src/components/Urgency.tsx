"use client";

import { useStore, scrollToBuy } from "@/lib/store";
import type { PublicProduct } from "@/lib/product";
import { brl } from "@/lib/format";
import Countdown from "./Countdown";

/** Mid-page conversion block: real stock + real promo deadline + a second CTA. */
export default function Urgency({ product }: { product: PublicProduct }) {
  const { size, buyNow } = useStore();
  if (product.stock <= 0) return null;

  return (
    <section className="bg-lime py-10">
      <div className="mx-auto flex max-w-3xl flex-col items-center gap-4 px-4 text-center">
        <h2 className="text-2xl font-black sm:text-3xl">Aproveite o preço promocional</h2>
        {product.stock <= 30 && <p className="font-bold">Restam apenas {product.stock} unidades com Frete Grátis!</p>}
        <Countdown endsAt={product.promoEndsAt} />
        <p className="text-lg">
          De <span className="line-through opacity-60">{brl(product.oldPriceCents)}</span> por <b className="text-2xl">{brl(product.priceCents)}</b>
        </p>
        <button onClick={() => (size ? buyNow() : scrollToBuy())} className="inline-flex h-14 w-full max-w-md items-center justify-center rounded-2xl bg-ink px-6 text-base font-extrabold uppercase tracking-wide text-white">
          Quero o meu agora
        </button>
      </div>
    </section>
  );
}
