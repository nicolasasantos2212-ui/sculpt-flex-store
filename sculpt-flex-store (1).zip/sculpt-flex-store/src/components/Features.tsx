"use client";

import { useState } from "react";
import { Shirt, ShieldCheck, Sparkles, Wind } from "lucide-react";
import { FEATURES } from "@/content/copy";

const ICONS = { shield: ShieldCheck, peach: Sparkles, back: Shirt, wind: Wind } as const;
const EMOJI = { shield: "🛡️", peach: "🍑", back: "🧘‍♀️", wind: "🌬️" } as const;

/** Benefit cards. Tap/hover to expand on mobile and desktop. */
export default function Features() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section className="bg-ink py-12 text-white">
      <div className="mx-auto max-w-6xl px-4">
        <h2 className="text-center text-2xl font-black sm:text-3xl">
          Feito para <span className="text-lime">treinar e arrasar</span>
        </h2>
        <div className="mt-8 grid gap-3 sm:grid-cols-2">
          {FEATURES.map((f, i) => {
            const Icon = ICONS[f.icon];
            const isOpen = open === i;
            return (
              <button
                key={f.title}
                onClick={() => setOpen(isOpen ? null : i)}
                onMouseEnter={() => setOpen(i)}
                aria-expanded={isOpen}
                className={`rounded-2xl border p-5 text-left transition ${isOpen ? "border-lime bg-white/10" : "border-white/10 bg-white/5"}`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl" aria-hidden>
                    {EMOJI[f.icon]}
                  </span>
                  <h3 className="flex-1 text-lg font-bold">{f.title}</h3>
                  <Icon className="h-5 w-5 text-lime" aria-hidden />
                </div>
                <p className={`overflow-hidden text-neutral-300 transition-all ${isOpen ? "mt-3 max-h-40 opacity-100" : "max-h-0 opacity-0"}`}>{f.text}</p>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
