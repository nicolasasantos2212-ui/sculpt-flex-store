"use client";

import { useEffect, useState } from "react";
import type { PublicProduct } from "@/lib/product";
import { scrollToBuy, useStore } from "@/lib/store";
import { brl } from "@/lib/format";

/** Mobile-only bottom bar. Appears after the main CTA scrolls out of view. */
export default function StickyBuy({ product }: { product: PublicProduct }) {
  const { size, buyNow, checkoutOpen } = useStore();
  const [show, setShow] = useState(false);

  useEffect(() => {
    const el = document.getElementById("comprar");
    if (!el) return;
    const io = new IntersectionObserver(([entry]) => setShow(!entry.isIntersecting && entry.boundingClientRect.top < 0), { threshold: 0 });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  if (!show || checkoutOpen || product.stock <= 0) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-30 border-t border-neutral-200 bg-white/95 p-3 backdrop-blur lg:hidden" style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" }}>
      <div className="mx-auto flex max-w-md items-center gap-3">
        <div className="leading-tight">
          <div className="text-xs text-neutral-400 line-through">{brl(product.oldPriceCents)}</div>
          <div className="text-xl font-black">{brl(product.priceCents)}</div>
        </div>
        <button onClick={() => (size ? buyNow() : scrollToBuy())} className="btn-cta !py-3.5">
          Comprar agora
        </button>
      </div>
    </div>
  );
}
