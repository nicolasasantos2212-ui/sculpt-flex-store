"use client";

import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import type { ImageOpt } from "@/lib/product";

/** Swipeable gallery. Picking a color in the buy box jumps to that color's photo. */
export default function Gallery({ images, color }: { images: ImageOpt[]; color: string }) {
  const [i, setI] = useState(0);
  const startX = useRef<number | null>(null);

  useEffect(() => {
    const idx = images.findIndex((im) => im.color === color);
    if (idx >= 0) setI(idx);
  }, [color, images]);

  if (!images.length) return null;
  const go = (d: number) => setI((v) => (v + d + images.length) % images.length);
  const current = images[i] ?? images[0];

  return (
    <div className="lg:sticky lg:top-28 lg:self-start">
      <div
        className="relative aspect-[4/5] select-none overflow-hidden rounded-2xl bg-neutral-100"
        onTouchStart={(e) => (startX.current = e.touches[0].clientX)}
        onTouchEnd={(e) => {
          if (startX.current === null) return;
          const dx = e.changedTouches[0].clientX - startX.current;
          if (Math.abs(dx) > 40) go(dx < 0 ? 1 : -1);
          startX.current = null;
        }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img key={current.url} src={current.url} alt={current.alt} className="h-full w-full object-cover" loading="eager" decoding="async" />
        <span className="absolute left-3 top-3 rounded-full bg-rose px-3 py-1 text-xs font-extrabold text-white">50% OFF</span>
        <button onClick={() => go(-1)} aria-label="Foto anterior" className="absolute left-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 shadow">
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button onClick={() => go(1)} aria-label="Próxima foto" className="absolute right-2 top-1/2 flex h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-white/90 shadow">
          <ChevronRight className="h-5 w-5" />
        </button>
        <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 gap-1.5">
          {images.map((_, idx) => (
            <span key={idx} className={`h-1.5 rounded-full transition-all ${idx === i ? "w-5 bg-white" : "w-1.5 bg-white/60"}`} />
          ))}
        </div>
      </div>

      <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto">
        {images.map((im, idx) => (
          <button
            key={im.url}
            onClick={() => setI(idx)}
            aria-label={`Ver foto: ${im.alt}`}
            className={`h-20 w-16 shrink-0 overflow-hidden rounded-lg border-2 ${idx === i ? "border-ink" : "border-transparent opacity-70"}`}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={im.url} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
}
