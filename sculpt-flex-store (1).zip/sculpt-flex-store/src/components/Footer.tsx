import { BRAND } from "@/content/copy";
import type { PublicProduct } from "@/lib/product";

export default function Footer({ product }: { product: PublicProduct }) {
  return (
    <footer className="bg-ink px-4 pb-28 pt-10 text-sm text-neutral-400 lg:pb-10">
      <div className="mx-auto max-w-6xl">
        <p className="text-lg font-black text-white">{BRAND}</p>
        <p className="mt-2">
          Dúvidas? Fale com a gente no{" "}
          <a className="font-semibold text-lime underline" href={`https://wa.me/${product.whatsapp}`} target="_blank" rel="noopener noreferrer">
            WhatsApp
          </a>
          .
        </p>
        {/* Brazilian e-commerce law (Decreto 7.962/2013) requires seller identification. Fill in your real data. */}
        <p className="mt-4 text-xs">
          [Razão social] · CNPJ 00.000.000/0001-00 · [Endereço completo] · [E-mail de contato]
        </p>
        <p className="mt-1 text-xs">© {new Date().getFullYear()} {BRAND}. Todos os direitos reservados.</p>
      </div>
    </footer>
  );
}
