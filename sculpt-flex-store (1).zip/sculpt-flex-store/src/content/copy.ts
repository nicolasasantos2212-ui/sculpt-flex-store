/**
 * Static store copy. Edit freely.
 *
 * IMPORTANT: every claim below must be TRUE for the product you actually ship
 * (CDC / CONAR rules for advertising in Brazil). Test the fabric yourself
 * (opacity, squat test) and confirm shipping times with your supplier.
 */

export const BRAND = "SCULPT & FLEX";

/** Be realistic: dropshipping from abroad is often slower than domestic stock. */
export const DELIVERY_ESTIMATE = "10 a 20 dias úteis";

export const FEATURES = [
  {
    icon: "shield",
    title: "Zero Transparência",
    text: "Tecido seamless de alta densidade, pensado para não ficar transparente no agachamento.",
  },
  {
    icon: "peach",
    title: "Efeito Empina Bumbum & Modelador",
    text: "Modelagem anatômica que valoriza as curvas e desenha a silhueta.",
  },
  {
    icon: "back",
    title: "Costas Abertas & Alta Sustentação",
    text: "Sustentação premium sem machucar os ombros, com visual ousado nas costas.",
  },
  {
    icon: "wind",
    title: "Respirável & Canelado",
    text: "Tecido canelado que ajuda no controle de temperatura e na secagem rápida do suor.",
  },
] as const;

/**
 * Typical size chart in cm (body measurements). CONFIRM with your supplier's
 * chart before launch — wrong sizing is the #1 cause of returns in apparel.
 */
export const SIZE_GUIDE = [
  { size: "S", bust: "80–86", waist: "62–68", hip: "86–92" },
  { size: "M", bust: "86–92", waist: "68–74", hip: "92–98" },
  { size: "L", bust: "92–98", waist: "74–80", hip: "98–104" },
];

export const FAQ = [
  {
    q: "Qual o prazo de entrega?",
    a: `O prazo estimado é de ${DELIVERY_ESTIMATE} após a postagem. O frete é grátis para todo o Brasil e você recebe o código de rastreio por e-mail/WhatsApp assim que o pedido for enviado.`,
  },
  {
    q: "Posso trocar ou devolver?",
    a: "Sim. Você tem 7 dias corridos após o recebimento para desistir da compra (direito de arrependimento), e também pode solicitar troca por tamanho. Fale com a gente pelo WhatsApp e orientamos todo o processo.",
  },
  {
    q: "Como lavar o macacão?",
    a: "Lave à mão ou na máquina em ciclo delicado, com água fria, dentro de um saquinho de proteção. Não use alvejante nem amaciante, não torça e seque à sombra.",
  },
  {
    q: "Como escolher meu tamanho?",
    a: "Clique em “Guia de medidas” ao lado dos tamanhos e compare busto, cintura e quadril. Se estiver entre dois tamanhos, escolha o maior para mais conforto ou o menor para mais compressão.",
  },
  {
    q: "Quais as formas de pagamento?",
    a: "PIX (com 10% de desconto) e cartão de crédito em até 12x. Seus dados são tratados de forma segura.",
  },
  {
    q: "Como acompanho meu pedido?",
    a: "Assim que o pedido for postado enviamos o código de rastreio. Você também pode chamar no WhatsApp com o número do pedido a qualquer momento.",
  },
];
